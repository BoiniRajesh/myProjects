#!/usr/bin/env python3
"""
Startup script for IPL Dream11 Team Predictor
This script provides an easy way to start the application
"""

import os
import sys
import subprocess

def check_dependencies():
    """Check if all required dependencies are installed"""
    try:
        import flask
        import pandas
        import numpy
        import requests
        from bs4 import BeautifulSoup
        from werkzeug.security import generate_password_hash, check_password_hash
        return True
    except ImportError as e:
        print(f"Missing dependency: {e}")
        return False

def install_dependencies():
    """Install required dependencies"""
    print("Installing dependencies...")
    try:
        subprocess.check_call([sys.executable, "-m", "pip", "install", "-r", "requirements.txt"])
        print("Dependencies installed successfully!")
        return True
    except subprocess.CalledProcessError as e:
        print(f"Failed to install dependencies: {e}")
        return False

def main():
    """Main startup function"""
    print("=" * 60)
    print("IPL Dream11 Team Predictor - Startup Script")
    print("=" * 60)
    
    # Check if dependencies are installed
    if not check_dependencies():
        print("\nDependencies not found. Installing...")
        if not install_dependencies():
            print("Failed to install dependencies. Please run manually:")
            print("  pip install -r requirements.txt")
            return False
    
    print("\nStarting IPL Dream11 Team Predictor...")
    print("=" * 60)
    print("Application will be available at: http://localhost:5000")
    print("Default admin credentials:")
    print("  Email: admin@iplpredictor.com")
    print("  Password: admin123")
    print("=" * 60)
    print("Press Ctrl+C to stop the application")
    print("=" * 60)
    
    # Start the Flask application
    try:
        from dream import app
        app.run(debug=True, host='0.0.0.0', port=5000)
    except KeyboardInterrupt:
        print("\n\nApplication stopped by user.")
    except Exception as e:
        print(f"\nError starting application: {e}")
        return False
    
    return True

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)
