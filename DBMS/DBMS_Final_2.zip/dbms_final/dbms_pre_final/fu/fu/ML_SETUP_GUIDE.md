# ML Setup Guide for IPL Dream11 Predictor

## 🚀 Quick Start

### 1. Install Dependencies

```bash
# Install ML libraries
pip install scikit-learn==1.3.0 joblib==1.3.2

# Or install all requirements
pip install -r requirements.txt
```

### 2. Train ML Models

```bash
# Run the training script
python train_ml_models.py
```

This will:
- Load historical IPL data
- Create training features
- Train multiple ML models
- Save models to `models/` directory
- Display training progress and accuracy

### 3. Test ML Predictions

```bash
# Test the ML implementation
python test_ml_predictions.py
```

This will:
- Test individual player predictions
- Test player vs player weights
- Test team generation
- Display sample results

### 4. Run the Application

```bash
# Start the Flask application
python dream.py
```

The application now uses ML predictions by default!

## 📊 What's New

### ML Features Added

1. **Smart Player Predictions**: ML models predict fantasy points based on:
   - Historical performance
   - Head-to-head records
   - Venue performance
   - Recent form
   - Player vs player matchups

2. **Player vs Player Weights**: Dynamic weight matrix that stores performance relationships between players

3. **Multiple ML Models**: 
   - Random Forest (primary)
   - Gradient Boosting (secondary)
   - Linear Regression (baseline)

4. **Automatic Fallback**: If ML fails, automatically falls back to manual algorithm

### API Changes

- **`/generate_team`** now supports ML predictions (default)
- **`use_ml`** parameter to toggle ML/manual mode
- **`method`** in response indicates which method was used

## 🔧 Configuration

### Model Settings

Edit `ml_models.py` to adjust:
- Model parameters
- Feature engineering
- Training data processing
- Prediction thresholds

### Training Data

Ensure these files exist:
- `IPl Ball-by-Ball 2008-2023.csv`
- `IPL Mathces 2008-2023.csv`
- Excel files in `Teams/` directory

## 📈 Performance

### Expected Improvements

- **More Accurate Predictions**: ML models learn complex patterns
- **Better Team Selection**: Optimized player combinations
- **Contextual Awareness**: Considers opponent and venue
- **Adaptive Learning**: Improves with more data

### Monitoring

Check the console output for:
- Training progress
- Model accuracy scores
- Prediction confidence
- Fallback usage

## 🐛 Troubleshooting

### Common Issues

1. **"No training data available"**
   - Ensure CSV files are in the correct directory
   - Check file names match exactly

2. **"ML prediction failed, falling back to manual"**
   - Check if models were trained successfully
   - Verify model files exist in `models/` directory

3. **"Error loading models"**
   - Delete `models/` directory and retrain
   - Check file permissions

### Debug Mode

Enable debug logging by adding to `dream.py`:

```python
import logging
logging.basicConfig(level=logging.DEBUG)
```

## 📁 File Structure

```
├── ml_models.py              # ML implementation
├── train_ml_models.py        # Training script
├── test_ml_predictions.py    # Testing script
├── dream.py                  # Updated main app
├── models/                   # Saved models
│   ├── random_forest_model.pkl
│   ├── gradient_boosting_model.pkl
│   ├── linear_regression_model.pkl
│   ├── main_scaler.pkl
│   └── player_weights.pkl
├── requirements.txt          # Updated dependencies
├── ML_IMPLEMENTATION.md      # Technical documentation
└── ML_SETUP_GUIDE.md        # This guide
```

## 🎯 Next Steps

1. **Train Models**: Run `python train_ml_models.py`
2. **Test System**: Run `python test_ml_predictions.py`
3. **Start App**: Run `python dream.py`
4. **Generate Teams**: Use the web interface to create teams
5. **Monitor Performance**: Check console for ML usage

## 💡 Tips

- **First Run**: Training may take a few minutes
- **Model Updates**: Retrain periodically with new data
- **Performance**: ML predictions are more accurate but slightly slower
- **Fallback**: System always works even if ML fails

## 🆘 Support

If you encounter issues:

1. Check the console output for error messages
2. Verify all dependencies are installed
3. Ensure data files are present and readable
4. Try retraining the models
5. Check the ML_IMPLEMENTATION.md for technical details

---

**Ready to use ML-powered Dream11 predictions!** 🏏🤖
