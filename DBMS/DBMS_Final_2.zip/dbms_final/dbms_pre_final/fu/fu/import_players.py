#!/usr/bin/env python3
"""
Script to import players from Excel files and update the database
"""

import pandas as pd
import os
from database import DatabaseManager
import random

def get_team_mapping():
    """Map Excel filenames to team names and IDs"""
    return {
        'mi.xlsx': {'name': 'Mumbai Indians', 'short': 'MI', 'id': 1, 'color': '667eea'},
        'csk.xlsx': {'name': 'Chennai Super Kings', 'short': 'CSK', 'id': 2, 'color': 'ffd700'},
        'rcb.xlsx': {'name': 'Royal Challengers Bangalore', 'short': 'RCB', 'id': 3, 'color': 'ff0000'},
        'kkr.xlsx': {'name': 'Kolkata Knight Riders', 'short': 'KKR', 'id': 4, 'color': '9c27b0'},
        'dc.xlsx': {'name': 'Delhi Capitals', 'short': 'DC', 'id': 5, 'color': '2196f3'},
        'pbks.xlsx': {'name': 'Punjab Kings', 'short': 'PBKS', 'id': 6, 'color': 'ff9800'},
        'rr.xlsx': {'name': 'Rajasthan Royals', 'short': 'RR', 'id': 7, 'color': 'e91e63'},
        'srh.xlsx': {'name': 'Sunrisers Hyderabad', 'short': 'SRH', 'id': 8, 'color': 'ff5722'},
        'gt.xlsx': {'name': 'Gujarat Titans', 'short': 'GT', 'id': 9, 'color': '4caf50'},
        'lsg.xlsx': {'name': 'Lucknow Super Giants', 'short': 'LSG', 'id': 10, 'color': '795548'}
    }

def determine_player_position(player_name):
    """Determine player position based on name patterns and common knowledge"""
    # This is a simplified approach - in a real system, you'd have more data
    position_keywords = {
        'Wicket-keeper': ['dhoni', 'pant', 'rahul', 'samson', 'buttler', 'kishan', 'conway', 'wade'],
        'Batsman': ['sharma', 'kohli', 'gill', 'gaikwad', 'warner', 'williamson', 'gayle', 'agarwal', 'shaw', 'dhawan'],
        'Bowler': ['bumrah', 'chahar', 'siraj', 'shami', 'rabada', 'archer', 'kumar', 'khan', 'pathirana', 'madhwal'],
        'All-rounder': ['jadeja', 'pandya', 'pollard', 'maxwell', 'russell', 'narine', 'stokes', 'patel', 'dube', 'ali']
    }
    
    player_lower = player_name.lower()
    
    for position, keywords in position_keywords.items():
        for keyword in keywords:
            if keyword in player_lower:
                return position
    
    # Default to batsman if no match found
    return 'Batsman'

def generate_fantasy_price(position, player_name):
    """Generate fantasy price based on position and player reputation"""
    base_prices = {
        'Wicket-keeper': 8.5,
        'Batsman': 9.0,
        'Bowler': 8.0,
        'All-rounder': 9.5
    }
    
    # Premium players get higher prices
    premium_players = ['dhoni', 'kohli', 'sharma', 'bumrah', 'jadeja', 'pandya', 'warner', 'buttler', 'samson']
    
    base_price = base_prices.get(position, 8.5)
    
    # Add premium for known players
    if any(premium in player_name.lower() for premium in premium_players):
        base_price += 1.0
    
    # Add some randomness
    variation = random.uniform(-0.5, 0.5)
    final_price = round(base_price + variation, 1)
    
    # Ensure price is within reasonable bounds
    return max(7.0, min(11.0, final_price))

def import_players_from_excel():
    """Import all players from Excel files"""
    db = DatabaseManager()
    team_mapping = get_team_mapping()
    
    # Clear existing players
    conn = db.get_connection()
    cursor = conn.cursor()
    cursor.execute("DELETE FROM players")
    conn.commit()
    conn.close()
    
    all_players = []
    
    for filename in os.listdir('Teams'):
        if filename.endswith('.xlsx'):
            team_info = team_mapping.get(filename)
            if not team_info:
                print(f"Unknown team file: {filename}")
                continue
            
            print(f"Processing {team_info['name']}...")
            
            try:
                # Read Excel file
                df = pd.read_excel(f'Teams/{filename}')
                
                # Get player names from first column
                player_names = df.iloc[:, 0].dropna().tolist()
                
                for player_name in player_names:
                    if pd.isna(player_name) or str(player_name).strip() == '':
                        continue
                    
                    player_name = str(player_name).strip()
                    position = determine_player_position(player_name)
                    price = generate_fantasy_price(position, player_name)
                    
                    # Generate avatar URL
                    avatar_url = f"https://ui-avatars.com/api/?name={player_name.replace(' ', '+')}&size=150&background={team_info['color']}&color=fff&bold=true"
                    
                    all_players.append({
                        'team_id': team_info['id'],
                        'name': player_name,
                        'position': position,
                        'price': price,
                        'image_url': avatar_url
                    })
                
                print(f"  Added {len(player_names)} players")
                
            except Exception as e:
                print(f"Error processing {filename}: {e}")
    
    # Insert all players into database
    if all_players:
        conn = db.get_connection()
        cursor = conn.cursor()
        
        for player in all_players:
            cursor.execute("""
                INSERT INTO players (team_id, name, position, price, image_url)
                VALUES (?, ?, ?, ?, ?)
            """, (player['team_id'], player['name'], player['position'], 
                  player['price'], player['image_url']))
        
        conn.commit()
        conn.close()
        
        print(f"\nTotal players imported: {len(all_players)}")
        
        # Show summary by team
        for team_info in team_mapping.values():
            team_players = [p for p in all_players if p['team_id'] == team_info['id']]
            if team_players:
                print(f"{team_info['name']}: {len(team_players)} players")
    
    return len(all_players)

def main():
    """Main function"""
    print("=" * 60)
    print("IPL Players Import from Excel Files")
    print("=" * 60)
    
    if not os.path.exists('Teams'):
        print("Teams folder not found!")
        return False
    
    try:
        total_players = import_players_from_excel()
        print(f"\n[SUCCESS] Successfully imported {total_players} players!")
        return True
    except Exception as e:
        print(f"[ERROR] Error: {e}")
        return False

if __name__ == "__main__":
    success = main()
    if success:
        print("\n[SUCCESS] Players import completed successfully!")
    else:
        print("\n[ERROR] Players import failed!")
