"""
ML Models for IPL Dream11 Team Prediction
This module implements machine learning models to predict player performance
and generate optimal team combinations.
"""

import pandas as pd
import numpy as np
import joblib
import os
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.metrics import mean_squared_error, r2_score
from collections import defaultdict
import warnings
warnings.filterwarnings('ignore')

class IPLMLPredictor:
    def __init__(self, data_dir=None):
        """Initialize the ML predictor with data directory"""
        self.data_dir = data_dir or os.path.dirname(os.path.abspath(__file__))
        self.byb_data = None
        self.match_data = None
        self.player_weights = {}
        self.models = {}
        self.scalers = {}
        self.label_encoders = {}
        self.load_data()
        
    def load_data(self):
        """Load IPL data from CSV files"""
        try:
            self.byb_data = pd.read_csv(os.path.join(self.data_dir, 'IPl Ball-by-Ball 2008-2023.csv'))
            self.match_data = pd.read_csv(os.path.join(self.data_dir, 'IPL Mathces 2008-2023.csv'))
            print("Data loaded successfully")
        except Exception as e:
            print(f"Error loading data: {e}")
            self.byb_data = pd.DataFrame()
            self.match_data = pd.DataFrame()
    
    def create_player_features(self, player_name, opponent_team=None, venue=None):
        """Create comprehensive features for a player"""
        # Always create the same set of features to ensure consistency
        features = self._get_default_features()
        
        # Basic player stats
        player_matches = self.byb_data[
            (self.byb_data['batsman'] == player_name) | 
            (self.byb_data['bowler'] == player_name) |
            (self.byb_data['fielder'] == player_name)
        ]
        
        if len(player_matches) == 0:
            return features
        
        # Batting features
        batting_data = self.byb_data[self.byb_data['batsman'] == player_name]
        if len(batting_data) > 0:
            batting_features = self._get_batting_features(batting_data, player_name)
            features.update(batting_features)
        
        # Bowling features
        bowling_data = self.byb_data[self.byb_data['bowler'] == player_name]
        if len(bowling_data) > 0:
            bowling_features = self._get_bowling_features(bowling_data, player_name)
            features.update(bowling_features)
        
        # Fielding features
        fielding_data = self.byb_data[self.byb_data['fielder'] == player_name]
        if len(fielding_data) > 0:
            fielding_features = self._get_fielding_features(fielding_data, player_name)
            features.update(fielding_features)
        
        # Head-to-head features if opponent specified
        if opponent_team:
            h2h_features = self._get_head_to_head_features(player_name, opponent_team)
            features.update(h2h_features)
        
        # Venue features
        if venue:
            venue_features = self._get_venue_features(player_name, venue)
            features.update(venue_features)
        
        # Recent form features
        form_features = self._get_recent_form_features(player_name)
        features.update(form_features)
        
        return features
    
    def _get_default_features(self):
        """Return default features for players with no data - includes ALL possible features"""
        return {
            # Batting features
            'avg_runs': 0, 'avg_balls': 0, 'strike_rate': 100, 'avg_fours': 0, 'avg_sixes': 0,
            # Bowling features
            'avg_wickets': 0, 'avg_overs': 0, 'economy': 6.0, 'avg_maidens': 0,
            # Fielding features
            'avg_catches': 0, 'avg_run_outs': 0, 'avg_stumpings': 0,
            # General features
            'matches_played': 0, 'recent_form': 0, 'consistency': 0,
            # Head-to-head features
            'h2h_avg_runs': 0, 'h2h_avg_wickets': 0, 'h2h_matches': 0,
            # Venue features
            'venue_avg_runs': 0, 'venue_avg_wickets': 0, 'venue_matches': 0,
            # Form features
            'form_trend': 0
        }
    
    def _get_batting_features(self, batting_data, player_name):
        """Extract batting features"""
        features = {}
        
        # Group by match and calculate stats properly
        match_stats = batting_data.groupby('id').agg({
            'batsman_runs': ['sum', 'count', lambda x: (x == 4).sum(), lambda x: (x == 6).sum()]
        }).reset_index()
        
        # Flatten column names
        match_stats.columns = ['match_id', 'runs', 'balls', 'fours', 'sixes']
        
        if len(match_stats) > 0:
            features['avg_runs'] = match_stats['runs'].mean()
            features['avg_balls'] = match_stats['balls'].mean()
            features['strike_rate'] = (match_stats['runs'].sum() / match_stats['balls'].sum() * 100) if match_stats['balls'].sum() > 0 else 100
            features['avg_fours'] = match_stats['fours'].mean()
            features['avg_sixes'] = match_stats['sixes'].mean()
            features['consistency'] = 1 - (match_stats['runs'].std() / match_stats['runs'].mean()) if match_stats['runs'].mean() > 0 else 0
        else:
            features.update({'avg_runs': 0, 'avg_balls': 0, 'strike_rate': 100, 'avg_fours': 0, 'avg_sixes': 0, 'consistency': 0})
        
        return features
    
    def _get_bowling_features(self, bowling_data, player_name):
        """Extract bowling features"""
        features = {}
        
        # Group by match
        match_stats = bowling_data.groupby('id').agg({
            'is_wicket': 'sum',
            'total_runs': 'sum',
            'ball': 'count'
        }).reset_index()
        
        match_stats.columns = ['match_id', 'wickets', 'runs_conceded', 'balls']
        match_stats['overs'] = match_stats['balls'] / 6
        
        if len(match_stats) > 0:
            features['avg_wickets'] = match_stats['wickets'].mean()
            features['avg_overs'] = match_stats['overs'].mean()
            features['economy'] = (match_stats['runs_conceded'].sum() / match_stats['overs'].sum()) if match_stats['overs'].sum() > 0 else 6.0
            features['avg_maidens'] = len(match_stats[match_stats['runs_conceded'] == 0]) / len(match_stats)
        else:
            features.update({'avg_wickets': 0, 'avg_overs': 0, 'economy': 6.0, 'avg_maidens': 0})
        
        return features
    
    def _get_fielding_features(self, fielding_data, player_name):
        """Extract fielding features"""
        features = {}
        
        catches = len(fielding_data[fielding_data['dismissal_kind'] == 'caught'])
        run_outs = len(fielding_data[fielding_data['dismissal_kind'] == 'run out'])
        stumpings = len(fielding_data[fielding_data['dismissal_kind'] == 'stumped'])
        
        matches_played = len(fielding_data['id'].unique())
        
        features['avg_catches'] = catches / matches_played if matches_played > 0 else 0
        features['avg_run_outs'] = run_outs / matches_played if matches_played > 0 else 0
        features['avg_stumpings'] = stumpings / matches_played if matches_played > 0 else 0
        
        return features
    
    def _get_head_to_head_features(self, player_name, opponent_team):
        """Extract head-to-head features against specific team"""
        features = {}
        
        # Get matches against opponent team
        opponent_matches = self.match_data[
            (self.match_data['team1'] == opponent_team) | 
            (self.match_data['team2'] == opponent_team)
        ]['id'].tolist()
        
        if not opponent_matches:
            return {'h2h_avg_runs': 0, 'h2h_avg_wickets': 0, 'h2h_matches': 0}
        
        # Player performance in those matches
        h2h_data = self.byb_data[
            (self.byb_data['id'].isin(opponent_matches)) & 
            ((self.byb_data['batsman'] == player_name) | (self.byb_data['bowler'] == player_name))
        ]
        
        if len(h2h_data) == 0:
            return {'h2h_avg_runs': 0, 'h2h_avg_wickets': 0, 'h2h_matches': 0}
        
        # Batting against opponent
        batting_h2h = h2h_data[h2h_data['batsman'] == player_name]
        if len(batting_h2h) > 0:
            h2h_runs = batting_h2h.groupby('id')['batsman_runs'].sum().mean()
        else:
            h2h_runs = 0
        
        # Bowling against opponent
        bowling_h2h = h2h_data[h2h_data['bowler'] == player_name]
        if len(bowling_h2h) > 0:
            h2h_wickets = bowling_h2h.groupby('id')['is_wicket'].sum().mean()
        else:
            h2h_wickets = 0
        
        features['h2h_avg_runs'] = h2h_runs
        features['h2h_avg_wickets'] = h2h_wickets
        features['h2h_matches'] = len(h2h_data['id'].unique())
        
        return features
    
    def _get_venue_features(self, player_name, venue):
        """Extract venue-specific features"""
        features = {}
        
        # Get matches at specific venue
        venue_matches = self.match_data[self.match_data['venue'] == venue]['id'].tolist()
        
        if not venue_matches:
            return {'venue_avg_runs': 0, 'venue_avg_wickets': 0, 'venue_matches': 0}
        
        # Player performance at venue
        venue_data = self.byb_data[
            (self.byb_data['id'].isin(venue_matches)) & 
            ((self.byb_data['batsman'] == player_name) | (self.byb_data['bowler'] == player_name))
        ]
        
        if len(venue_data) == 0:
            return {'venue_avg_runs': 0, 'venue_avg_wickets': 0, 'venue_matches': 0}
        
        # Batting at venue
        batting_venue = venue_data[venue_data['batsman'] == player_name]
        if len(batting_venue) > 0:
            venue_runs = batting_venue.groupby('id')['batsman_runs'].sum().mean()
        else:
            venue_runs = 0
        
        # Bowling at venue
        bowling_venue = venue_data[venue_data['bowler'] == player_name]
        if len(bowling_venue) > 0:
            venue_wickets = bowling_venue.groupby('id')['is_wicket'].sum().mean()
        else:
            venue_wickets = 0
        
        features['venue_avg_runs'] = venue_runs
        features['venue_avg_wickets'] = venue_wickets
        features['venue_matches'] = len(venue_data['id'].unique())
        
        return features
    
    def _get_recent_form_features(self, player_name, recent_matches=5):
        """Extract recent form features"""
        features = {}
        
        # Get recent matches
        all_matches = self.byb_data[
            (self.byb_data['batsman'] == player_name) | 
            (self.byb_data['bowler'] == player_name)
        ]['id'].unique()
        
        if len(all_matches) == 0:
            return {'recent_form': 0, 'form_trend': 0}
        
        # Sort by match ID (assuming higher ID = more recent)
        recent_match_ids = sorted(all_matches)[-recent_matches:]
        
        recent_data = self.byb_data[self.byb_data['id'].isin(recent_match_ids)]
        
        # Recent batting form
        recent_batting = recent_data[recent_data['batsman'] == player_name]
        if len(recent_batting) > 0:
            recent_runs = recent_batting.groupby('id')['batsman_runs'].sum()
            recent_form = recent_runs.mean()
            form_trend = recent_runs.iloc[-1] - recent_runs.iloc[0] if len(recent_runs) > 1 else 0
        else:
            recent_form = 0
            form_trend = 0
        
        features['recent_form'] = recent_form
        features['form_trend'] = form_trend
        
        return features
    
    def create_training_data(self):
        """Create training dataset for ML models"""
        print("Creating training dataset...")
        
        training_data = []
        target_scores = []
        
        # Get all unique players
        all_players = set(self.byb_data['batsman'].unique()) | set(self.byb_data['bowler'].unique())
        all_players = [p for p in all_players if pd.notna(p)]
        
        print(f"Processing {len(all_players)} players...")
        
        # Limit to first 100 players for faster training (can be increased later)
        all_players = all_players[:100]
        print(f"Processing first {len(all_players)} players for faster training...")
        
        for i, player in enumerate(all_players):
            if i % 10 == 0:
                print(f"Processed {i}/{len(all_players)} players")
            
            try:
                # Get player's match history
                player_matches = self.byb_data[
                    (self.byb_data['batsman'] == player) | 
                    (self.byb_data['bowler'] == player)
                ]['id'].unique()
                
                # Limit to first 10 matches per player for faster processing
                player_matches = player_matches[:10]
                
                for match_id in player_matches:
                    try:
                        # Get match details
                        match_info = self.match_data[self.match_data['id'] == match_id]
                        if len(match_info) == 0:
                            continue
                        
                        match_row = match_info.iloc[0]
                        venue = match_row['venue']
                        
                        # Determine opponent team
                        team1 = match_row['team1']
                        team2 = match_row['team2']
                        
                        # Get player's team (simplified - would need better logic in real scenario)
                        player_team = team1  # This is simplified
                        opponent_team = team2 if player_team == team1 else team1
                        
                        # Create features
                        features = self.create_player_features(player, opponent_team, venue)
                        
                        # Calculate actual fantasy points for this match
                        actual_points = self._calculate_actual_fantasy_points(player, match_id)
                        
                        if actual_points is not None and actual_points > 0:
                            # Ensure all features are present and in the same order
                            standardized_features = self._get_default_features()
                            standardized_features.update(features)
                            training_data.append(standardized_features)
                            target_scores.append(actual_points)
                            
                    except Exception as e:
                        print(f"Error processing match {match_id} for player {player}: {e}")
                        continue
                        
            except Exception as e:
                print(f"Error processing player {player}: {e}")
                continue
        
        print(f"Created training dataset with {len(training_data)} samples")
        return training_data, target_scores
    
    def _calculate_actual_fantasy_points(self, player_name, match_id):
        """Calculate actual fantasy points for a player in a specific match"""
        match_data = self.byb_data[self.byb_data['id'] == match_id]
        
        points = 0
        
        # Batting points
        batting = match_data[match_data['batsman'] == player_name]
        if len(batting) > 0:
            runs = batting['batsman_runs'].sum()
            fours = len(batting[batting['batsman_runs'] == 4])
            sixes = len(batting[batting['batsman_runs'] == 6])
            
            points += runs + fours + sixes * 2
            
            # Milestone bonuses
            if runs >= 100:
                points += 16
            elif runs >= 50:
                points += 8
            elif runs >= 30:
                points += 4
            elif runs == 0 and len(batting) > 0:
                points -= 2
        
        # Bowling points
        bowling = match_data[match_data['bowler'] == player_name]
        if len(bowling) > 0:
            wickets = bowling['is_wicket'].sum()
            points += wickets * 25
            
            if wickets >= 5:
                points += 16
            elif wickets >= 4:
                points += 8
            elif wickets >= 3:
                points += 4
        
        # Fielding points
        catches = len(match_data[(match_data['fielder'] == player_name) & (match_data['dismissal_kind'] == 'caught')])
        stumpings = len(match_data[(match_data['fielder'] == player_name) & (match_data['dismissal_kind'] == 'stumped')])
        run_outs = len(match_data[(match_data['fielder'] == player_name) & (match_data['dismissal_kind'] == 'run out')])
        
        points += catches * 8 + stumpings * 12 + run_outs * 6
        
        return points if points > 0 else None
    
    def train_models(self):
        """Train multiple ML models"""
        print("Training ML models...")
        
        # Create training data
        X, y = self.create_training_data()
        
        if len(X) == 0:
            print("No training data available!")
            return
        
        # Convert to DataFrame
        X_df = pd.DataFrame(X)
        X_df = X_df.fillna(0)  # Fill missing values
        
        print(f"Training data shape: {X_df.shape}")
        print(f"Target data length: {len(y)}")
        
        # Check if we have enough data
        if len(X_df) < 10:
            print("Not enough training data! Using simple fallback models...")
            self._create_simple_models()
            return
        
        # Split data
        if len(X_df) > 20:
            X_train, X_test, y_train, y_test = train_test_split(X_df, y, test_size=0.2, random_state=42)
        else:
            # Use all data for training if we have very little
            X_train, X_test, y_train, y_test = X_df, X_df, y, y
        
        # Scale features
        scaler = StandardScaler()
        X_train_scaled = scaler.fit_transform(X_train)
        X_test_scaled = scaler.transform(X_test)
        
        self.scalers['main'] = scaler
        
        # Train different models
        models = {
            'random_forest': RandomForestRegressor(n_estimators=50, random_state=42, max_depth=10),
            'gradient_boosting': GradientBoostingRegressor(n_estimators=50, random_state=42, max_depth=5),
            'linear_regression': LinearRegression()
        }
        
        for name, model in models.items():
            try:
                print(f"Training {name}...")
                model.fit(X_train_scaled, y_train)
                
                # Evaluate
                y_pred = model.predict(X_test_scaled)
                mse = mean_squared_error(y_test, y_pred)
                r2 = r2_score(y_test, y_pred)
                
                print(f"{name} - MSE: {mse:.2f}, R2: {r2:.2f}")
                
                self.models[name] = model
            except Exception as e:
                print(f"Error training {name}: {e}")
                continue
        
        # Save models
        self.save_models()
        print("Models trained and saved successfully!")
    
    def _create_simple_models(self):
        """Create simple fallback models when training data is insufficient"""
        print("Creating simple fallback models...")
        
        # Simple models that don't require much training data
        self.models['linear_regression'] = LinearRegression()
        self.models['random_forest'] = RandomForestRegressor(n_estimators=10, random_state=42)
        
        # Create dummy scaler
        self.scalers['main'] = StandardScaler()
        
        # Save simple models
        self.save_models()
        print("Simple models created and saved!")
    
    def predict_player_performance(self, player_name, opponent_team=None, venue=None, model_name='random_forest'):
        """Predict fantasy points for a player"""
        # Try to use the specified model, fallback to available models
        available_models = list(self.models.keys())
        if model_name not in self.models and available_models:
            model_name = available_models[0]
            print(f"Model {model_name} not found, using {model_name}")
        elif not available_models:
            print("No models available, using fallback prediction")
            return self._fallback_prediction(player_name)
        
        try:
            # Create features
            features = self.create_player_features(player_name, opponent_team, venue)
            
            # Ensure all features are present and in the same order as training
            standardized_features = self._get_default_features()
            standardized_features.update(features)
            
            # Convert to DataFrame and scale
            X = pd.DataFrame([standardized_features])
            X = X.fillna(0)
            
            if 'main' in self.scalers:
                X_scaled = self.scalers['main'].transform(X)
            else:
                X_scaled = X.values
            
            # Predict
            prediction = self.models[model_name].predict(X_scaled)[0]
            return max(0, prediction)  # Ensure non-negative prediction
            
        except Exception as e:
            print(f"Error in ML prediction for {player_name}: {e}")
            return self._fallback_prediction(player_name)
    
    def _fallback_prediction(self, player_name):
        """Fallback prediction when ML models fail"""
        # Simple heuristic-based prediction
        try:
            # Get basic player stats
            player_data = self.byb_data[
                (self.byb_data['batsman'] == player_name) | 
                (self.byb_data['bowler'] == player_name)
            ]
            
            if len(player_data) == 0:
                return 20.0  # Default prediction for unknown players
            
            # Calculate basic stats
            batting_data = player_data[player_data['batsman'] == player_name]
            bowling_data = player_data[player_data['bowler'] == player_name]
            
            avg_runs = batting_data.groupby('id')['batsman_runs'].sum().mean() if len(batting_data) > 0 else 0
            avg_wickets = bowling_data.groupby('id')['is_wicket'].sum().mean() if len(bowling_data) > 0 else 0
            
            # Simple prediction based on historical averages
            prediction = (avg_runs * 1.2) + (avg_wickets * 15) + 10
            return max(5.0, min(100.0, prediction))  # Clamp between 5 and 100
            
        except Exception as e:
            print(f"Error in fallback prediction for {player_name}: {e}")
            return 20.0  # Default fallback
    
    def get_player_vs_player_weights(self, player1, player2):
        """Get weight/performance matrix for player vs player matchups"""
        if player1 not in self.player_weights:
            self.player_weights[player1] = {}
        
        if player2 not in self.player_weights[player1]:
            # Calculate head-to-head performance
            h2h_data = self.byb_data[
                ((self.byb_data['batsman'] == player1) & (self.byb_data['bowler'] == player2)) |
                ((self.byb_data['batsman'] == player2) & (self.byb_data['bowler'] == player1))
            ]
            
            if len(h2h_data) > 0:
                # Calculate performance metrics
                player1_batting = h2h_data[h2h_data['batsman'] == player1]
                player1_bowling = h2h_data[h2h_data['bowler'] == player1]
                
                if len(player1_batting) > 0:
                    avg_runs = player1_batting['batsman_runs'].sum() / len(player1_batting['id'].unique())
                else:
                    avg_runs = 0
                
                if len(player1_bowling) > 0:
                    avg_wickets = player1_bowling['is_wicket'].sum() / len(player1_bowling['id'].unique())
                else:
                    avg_wickets = 0
                
                # Weight based on performance (clamped to avoid extreme values)
                raw_weight = (avg_runs * 0.1 + avg_wickets * 2.5) / 10
                weight = max(0.85, min(1.15, raw_weight if raw_weight > 0 else 1.0))
            else:
                weight = 1.0  # Default weight if no head-to-head data
            
            self.player_weights[player1][player2] = weight
        
        return self.player_weights[player1][player2]
    
    def save_models(self):
        """Save trained models to disk"""
        model_dir = os.path.join(self.data_dir, 'models')
        os.makedirs(model_dir, exist_ok=True)
        
        # Save models
        for name, model in self.models.items():
            joblib.dump(model, os.path.join(model_dir, f'{name}_model.pkl'))
        
        # Save scalers
        for name, scaler in self.scalers.items():
            joblib.dump(scaler, os.path.join(model_dir, f'{name}_scaler.pkl'))
        
        # Save player weights
        joblib.dump(self.player_weights, os.path.join(model_dir, 'player_weights.pkl'))
        
        print(f"Models saved to {model_dir}")
    
    def load_models(self):
        """Load trained models from disk"""
        model_dir = os.path.join(self.data_dir, 'models')
        
        if not os.path.exists(model_dir):
            print("No saved models found!")
            return False
        
        try:
            # Load models
            for model_file in os.listdir(model_dir):
                if model_file.endswith('_model.pkl'):
                    name = model_file.replace('_model.pkl', '')
                    self.models[name] = joblib.load(os.path.join(model_dir, model_file))
            
            # Load scalers
            for scaler_file in os.listdir(model_dir):
                if scaler_file.endswith('_scaler.pkl'):
                    name = scaler_file.replace('_scaler.pkl', '')
                    self.scalers[name] = joblib.load(os.path.join(model_dir, scaler_file))
            
            # Load player weights
            weights_file = os.path.join(model_dir, 'player_weights.pkl')
            if os.path.exists(weights_file):
                self.player_weights = joblib.load(weights_file)
            
            print("Models loaded successfully!")
            return True
        except Exception as e:
            print(f"Error loading models: {e}")
            return False
    
    def generate_ml_team(self, team1_players, team2_players, budget=100.0):
        """Generate optimal team using ML predictions with progressive relaxation to always return 11 players."""
        print("Generating ML-based team...")
        
        all_players = team1_players + team2_players
        player_predictions = []
        
        # Precompute predicted points with clamped matchup influence
        for player in all_players:
            opponent_team = team2_players[0]['team_name'] if player['team_name'] == team1_players[0]['team_name'] else team1_players[0]['team_name']
            predicted_points = self.predict_player_performance(player['name'], opponent_team=opponent_team)
            
            # Use average weight (clamped) instead of multiplicative collapse
            weights = []
            opponents = (team2_players if player['team_name'] == team1_players[0]['team_name'] else team1_players)
            for opponent in opponents:
                weights.append(self.get_player_vs_player_weights(player['name'], opponent['name']))
            weight_factor = float(np.mean(weights)) if weights else 1.0
            weight_factor = max(0.9, min(1.1, weight_factor))
            
            final_points = predicted_points * weight_factor
            
            player_predictions.append({
                'player': player,
                'predicted_points': final_points,
                'value': (final_points / player['price']) if player.get('price', 0) else final_points
            })
        
        # Helper: selection with options
        def select_team(preds, budget_limit=None, enforce_positions=True):
            selected = []
            cost = 0.0
            pos_counts = {'Wicket-keeper': 0, 'Batsman': 0, 'Bowler': 0, 'All-rounder': 0}
            for pred in preds:
                p = pred['player']
                pos = p['position']
                price = p.get('price', 0) or 0
                if enforce_positions:
                    if pos == 'Wicket-keeper' and pos_counts['Wicket-keeper'] >= 1:
                        continue
                    if pos == 'Batsman' and pos_counts['Batsman'] >= 4:
                        continue
                    if pos == 'Bowler' and pos_counts['Bowler'] >= 3:
                        continue
                    if pos == 'All-rounder' and pos_counts['All-rounder'] >= 3:
                        continue
                if budget_limit is None or cost + price <= budget_limit:
                    selected.append({
                        **p,
                        'fantasy_points': pred['predicted_points'],
                        'is_captain': False,
                        'is_vice_captain': False
                    })
                    cost += price
                    if pos in pos_counts:
                        pos_counts[pos] += 1
                    if len(selected) >= 11:
                        break
            return selected, cost
        
        # Sort by value first
        player_predictions.sort(key=lambda x: x['value'], reverse=True)
        
        # Try selection with strict constraints and budget
        selected_players, total_cost = select_team(player_predictions, budget_limit=budget, enforce_positions=True)
        
        # Relax budget if needed
        if len(selected_players) < 11:
            selected_players, total_cost = select_team(player_predictions, budget_limit=None, enforce_positions=True)
        
        # Relax positions if still short
        if len(selected_players) < 11:
            selected_players, total_cost = select_team(player_predictions, budget_limit=None, enforce_positions=False)
        
        # Final fill ignoring constraints to guarantee 11
        if len(selected_players) < 11:
            already_ids = {sp.get('id') for sp in selected_players}
            for pred in player_predictions:
                pid = pred['player'].get('id')
                if pid in already_ids:
                    continue
                selected_players.append({
                    **pred['player'],
                    'fantasy_points': pred['predicted_points'],
                    'is_captain': False,
                    'is_vice_captain': False
                })
                total_cost += pred['player'].get('price', 0) or 0
                if len(selected_players) >= 11:
                    break
        
        # Ensure we have exactly 11
        if len(selected_players) > 11:
            selected_players = selected_players[:11]
            total_cost = sum(p.get('price', 0) or 0 for p in selected_players)
        
        # Captain and vice-captain
        if selected_players:
            selected_players.sort(key=lambda x: x['fantasy_points'], reverse=True)
            selected_players[0]['is_captain'] = True
            if len(selected_players) > 1:
                selected_players[1]['is_vice_captain'] = True
        
        return selected_players, total_cost

# Initialize global ML predictor
ml_predictor = None

def initialize_ml_predictor():
    """Initialize the global ML predictor"""
    global ml_predictor
    if ml_predictor is None:
        ml_predictor = IPLMLPredictor()
        # Try to load existing models, otherwise train new ones
        if not ml_predictor.load_models():
            print("Training new models...")
            ml_predictor.train_models()
    return ml_predictor

def get_ml_predictor():
    """Get the global ML predictor instance"""
    return initialize_ml_predictor()
