"""
Test script for ML predictions
This script tests the ML model implementation and compares it with manual predictions.
"""

import os
import sys
from ml_models import IPLMLPredictor

def test_ml_predictions():
    """Test ML prediction functionality"""
    print("=" * 60)
    print("Testing ML Predictions")
    print("=" * 60)
    
    # Initialize predictor
    predictor = IPLMLPredictor()
    
    # Check if data is available
    if predictor.byb_data.empty or predictor.match_data.empty:
        print("Error: No data available for testing!")
        return False
    
    print(f"Data loaded successfully:")
    print(f"- Ball-by-ball data: {len(predictor.byb_data)} records")
    print(f"- Match data: {len(predictor.match_data)} records")
    print()
    
    # Test individual player predictions
    test_players = ['Virat Kohli', 'MS Dhoni', 'Rohit Sharma', 'Jasprit Bumrah']
    
    print("Testing individual player predictions:")
    print("-" * 40)
    
    for player in test_players:
        try:
            prediction = predictor.predict_player_performance(player)
            print(f"{player:20}: {prediction:6.2f} points")
        except Exception as e:
            print(f"{player:20}: Error - {e}")
    
    print()
    
    # Test player vs player weights
    print("Testing player vs player weights:")
    print("-" * 40)
    
    try:
        weight = predictor.get_player_vs_player_weights('Virat Kohli', 'Jasprit Bumrah')
        print(f"Virat Kohli vs Jasprit Bumrah: {weight:.3f}")
        
        weight = predictor.get_player_vs_player_weights('MS Dhoni', 'Rohit Sharma')
        print(f"MS Dhoni vs Rohit Sharma: {weight:.3f}")
    except Exception as e:
        print(f"Error testing player weights: {e}")
    
    print()
    
    # Test team generation
    print("Testing ML team generation:")
    print("-" * 40)
    
    try:
        # Create sample teams
        team1_players = [
            {'name': 'Virat Kohli', 'position': 'Batsman', 'price': 10.0, 'team_name': 'RCB'},
            {'name': 'MS Dhoni', 'position': 'Wicket-keeper', 'price': 9.5, 'team_name': 'CSK'},
            {'name': 'Rohit Sharma', 'position': 'Batsman', 'price': 10.5, 'team_name': 'MI'},
            {'name': 'Jasprit Bumrah', 'position': 'Bowler', 'price': 9.0, 'team_name': 'MI'},
            {'name': 'Ravindra Jadeja', 'position': 'All-rounder', 'price': 9.0, 'team_name': 'CSK'}
        ]
        
        team2_players = [
            {'name': 'AB de Villiers', 'position': 'Batsman', 'price': 9.5, 'team_name': 'RCB'},
            {'name': 'Faf du Plessis', 'position': 'Batsman', 'price': 9.0, 'team_name': 'CSK'},
            {'name': 'Suryakumar Yadav', 'position': 'Batsman', 'price': 9.5, 'team_name': 'MI'},
            {'name': 'Yuzvendra Chahal', 'position': 'Bowler', 'price': 8.5, 'team_name': 'RCB'},
            {'name': 'Hardik Pandya', 'position': 'All-rounder', 'price': 9.0, 'team_name': 'MI'}
        ]
        
        result_players, total_cost = predictor.generate_ml_team(team1_players, team2_players)
        
        print(f"Generated team with {len(result_players)} players")
        print(f"Total cost: {total_cost:.1f}")
        print()
        
        print("Selected players:")
        for i, player in enumerate(result_players[:11], 1):
            print(f"{i:2}. {player['name']:20} ({player['position']:12}) - {player['fantasy_points']:6.2f} pts - {player['price']:4.1f} cr")
        
    except Exception as e:
        print(f"Error testing team generation: {e}")
        import traceback
        traceback.print_exc()
    
    print()
    print("=" * 60)
    print("ML Testing Complete")
    print("=" * 60)
    
    return True

if __name__ == "__main__":
    test_ml_predictions()
