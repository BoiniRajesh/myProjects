"""
Quick test script to verify ML fixes
"""

import os
import sys
from ml_models import IPLMLPredictor

def quick_test():
    """Quick test of ML functionality"""
    print("=" * 50)
    print("Quick ML Test")
    print("=" * 50)
    
    try:
        # Initialize predictor
        predictor = IPLMLPredictor()
        
        # Check data
        if predictor.byb_data.empty:
            print("❌ No ball-by-ball data!")
            return False
        
        if predictor.match_data.empty:
            print("❌ No match data!")
            return False
        
        print("✅ Data loaded successfully")
        print(f"   - Ball-by-ball: {len(predictor.byb_data)} records")
        print(f"   - Matches: {len(predictor.match_data)} records")
        
        # Test feature creation
        print("\n🔧 Testing feature creation...")
        try:
            features = predictor.create_player_features("Virat Kohli")
            print(f"✅ Features created: {len(features)} features")
            print(f"   Sample features: {list(features.keys())[:5]}")
        except Exception as e:
            print(f"❌ Feature creation failed: {e}")
            return False
        
        # Test training data creation
        print("\n📊 Testing training data creation...")
        try:
            X, y = predictor.create_training_data()
            print(f"✅ Training data created: {len(X)} samples")
            if len(X) > 0:
                print(f"   - Features per sample: {len(X[0])}")
                print(f"   - Target range: {min(y):.1f} - {max(y):.1f}")
        except Exception as e:
            print(f"❌ Training data creation failed: {e}")
            return False
        
        # Test model training
        print("\n🤖 Testing model training...")
        try:
            predictor.train_models()
            print(f"✅ Models trained: {list(predictor.models.keys())}")
        except Exception as e:
            print(f"❌ Model training failed: {e}")
            return False
        
        # Test prediction
        print("\n🎯 Testing predictions...")
        try:
            prediction = predictor.predict_player_performance("Virat Kohli")
            print(f"✅ Prediction successful: {prediction:.2f} points")
        except Exception as e:
            print(f"❌ Prediction failed: {e}")
            return False
        
        print("\n🎉 All tests passed!")
        return True
        
    except Exception as e:
        print(f"❌ Test failed with error: {e}")
        import traceback
        traceback.print_exc()
        return False

if __name__ == "__main__":
    success = quick_test()
    if success:
        print("\n✅ ML system is working correctly!")
    else:
        print("\n❌ ML system has issues that need fixing.")
