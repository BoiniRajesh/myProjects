# IPL Dream11 Team Predictor

A complete, production-ready Flask web application for predicting optimal IPL Dream11 teams using AI-powered algorithms. This application provides a comprehensive fantasy cricket experience with user management, team selection, and administrative controls.

## 🏏 Features

### Core Functionality
- **AI-Powered Team Prediction**: Advanced algorithm that analyzes player performance, team statistics, and match conditions
- **Dynamic Player Images**: Automatically fetches player photos from online sources
- **Real-time Data**: Latest player statistics and team performance data
- **Budget Management**: Smart budget allocation within Dream11 constraints
- **Captain & Vice-Captain Selection**: Strategic leadership choices

### User Management
- **Secure Authentication**: Email/password login with Werkzeug security
- **User Registration**: Complete profile with PAN, Aadhaar, address, gender, and referral code
- **User History**: Track past team selections and performance
- **Admin Dashboard**: Comprehensive user and team management

### Database Features
- **Normalized SQLite Schema**: Efficient data storage with proper relationships
- **User Data Security**: Encrypted passwords and secure data handling
- **Team Management**: Dynamic team activation/deactivation
- **Match Tracking**: Complete match and selection history

## 🚀 Quick Start

### Prerequisites
- Python 3.8 or higher
- pip (Python package installer)

### Installation

1. **Clone the repository**
   ```bash
   git clone <repository-url>
   cd ipl-dream11-predictor
   ```

2. **Install dependencies**
   ```bash
   pip install -r requirements.txt
   ```

3. **Run the application**
   ```bash
   python dream.py
   ```

4. **Access the application**
   - Open your browser and go to `http://localhost:5000`
   - Default admin credentials: `admin@iplpredictor.com` / `admin123`

## 📁 Project Structure

```
ipl-dream11-predictor/
├── dream.py                 # Main Flask application
├── database.py              # Database models and operations
├── requirements.txt         # Python dependencies
├── users.db                 # SQLite database (created automatically)
├── static/
│   └── style.css           # Main stylesheet
├── templates/
│   ├── home.html           # Landing page
│   ├── login.html          # Login/signup page
│   ├── index.html          # Match selection
│   ├── player.html         # Player selection interface
│   ├── result.html         # Team prediction results
│   ├── history.html        # User history
│   └── admin.html          # Admin dashboard
└── README.md               # This file
```

## 🎯 Application Flow

### 1. Homepage (`home.html`)
- Static, visually engaging landing page
- Feature highlights and statistics
- Call-to-action buttons for login/signup

### 2. Authentication (`login.html`)
- **Login**: Email and password authentication
- **Signup**: Complete user registration with:
  - Email and password
  - PAN number validation
  - Aadhaar number validation
  - Full address
  - Gender selection
  - Optional referral code

### 3. Match Selection (`index.html`)
- Display all available matches
- Team vs Team format
- Match date and venue information
- Direct navigation to player selection

### 4. Player Selection (`player.html`)
- **Dynamic Player Images**: Automatically fetched from online sources
- **Position Filtering**: Filter by Batsman, Bowler, All-rounder, Wicket-keeper
- **Budget Management**: Real-time cost tracking
- **Selection Constraints**: Exactly 11 players required
- **Interactive Interface**: Click to select/deselect players

### 5. Prediction Results (`result.html`)
- **AI-Generated Team**: Optimal 11-player lineup
- **Captain & Vice-Captain**: Strategic leadership choices
- **Team Statistics**: Cost breakdown and position distribution
- **Print Functionality**: Save team for reference

### 6. User History (`history.html`)
- **Past Selections**: Complete history of team predictions
- **Performance Tracking**: Points and statistics
- **Match Details**: Previous match information
- **Quick Access**: Direct links to past teams

### 7. Admin Dashboard (`admin.html`)
- **User Management**: Activate/deactivate users
- **Team Management**: Enable/disable teams
- **System Statistics**: User and team counts
- **Real-time Updates**: AJAX-powered status changes

## 🗄️ Database Schema

### Tables
- **users**: User accounts and profiles
- **teams**: IPL team information
- **players**: Player details and statistics
- **matches**: Match schedules and venues
- **match_selections**: User team selections
- **selected_players**: Individual player selections

### Key Features
- **Normalized Design**: Efficient data storage
- **Foreign Key Relationships**: Data integrity
- **Indexed Fields**: Optimized queries
- **Soft Deletes**: Data preservation

## 🔧 Technical Details

### Backend
- **Flask**: Web framework
- **SQLite**: Database management
- **Werkzeug**: Password hashing and security
- **Pandas & NumPy**: Data processing and algorithms
- **Requests & BeautifulSoup**: Web scraping for player images

### Frontend
- **HTML5**: Semantic markup
- **CSS3**: Modern styling with gradients and animations
- **JavaScript**: Interactive functionality
- **Responsive Design**: Mobile-friendly interface

### Security Features
- **Password Hashing**: Secure password storage
- **Session Management**: User authentication
- **Input Validation**: Form data sanitization
- **Admin Controls**: Access restrictions

## 🎨 UI/UX Features

### Design Elements
- **Modern Gradient Backgrounds**: Eye-catching visuals
- **Glass Morphism**: Frosted glass effects
- **Smooth Animations**: Hover effects and transitions
- **Responsive Layout**: Works on all devices
- **Intuitive Navigation**: Easy-to-use interface

### Color Scheme
- **Primary**: Blue to purple gradient
- **Accent**: Gold (#ffd700)
- **Success**: Green (#27ae60)
- **Error**: Red (#e74c3c)
- **Text**: White with opacity variations

## 📊 Algorithm Details

### Team Generation Algorithm
1. **Position Constraints**: 1 WK, 3 BAT, 3 BOWL, 4 AR
2. **Budget Optimization**: Maximize value within ₹100 budget
3. **Player Selection**: Price-based ranking system
4. **Captain Selection**: Random from selected players
5. **Vice-Captain**: Random from remaining players

### Data Processing
- **Player Analysis**: Performance metrics and pricing
- **Team Balance**: Optimal position distribution
- **Budget Allocation**: Smart cost management
- **Constraint Satisfaction**: Dream11 rules compliance

## 🔐 Security Considerations

### Authentication
- **Password Hashing**: bcrypt-based encryption
- **Session Security**: Secure session management
- **Input Validation**: Comprehensive form validation
- **SQL Injection Prevention**: Parameterized queries

### Data Protection
- **Personal Information**: Secure storage of PAN/Aadhaar
- **Admin Controls**: Restricted access to sensitive data
- **User Privacy**: Individual data isolation

## 🚀 Deployment

### Production Setup
1. **Environment Variables**: Set production secret key
2. **Database Migration**: Initialize production database
3. **Static Files**: Configure web server for static assets
4. **SSL Certificate**: Enable HTTPS for security
5. **Backup Strategy**: Regular database backups

### Recommended Hosting
- **Heroku**: Easy deployment with add-ons
- **AWS**: Scalable cloud infrastructure
- **DigitalOcean**: VPS with full control
- **PythonAnywhere**: Python-focused hosting

## 📈 Performance Optimization

### Database
- **Indexing**: Optimized query performance
- **Connection Pooling**: Efficient database connections
- **Query Optimization**: Reduced database load

### Frontend
- **Image Optimization**: Compressed player photos
- **CSS Minification**: Reduced file sizes
- **JavaScript Optimization**: Efficient client-side code

## 🧪 Testing

### Manual Testing
1. **User Registration**: Test all form validations
2. **Login/Logout**: Authentication flow
3. **Team Selection**: Player selection and constraints
4. **Admin Functions**: User and team management
5. **Responsive Design**: Mobile and desktop testing

### Automated Testing
- **Unit Tests**: Individual function testing
- **Integration Tests**: End-to-end workflows
- **Database Tests**: Data integrity verification

## 🐛 Troubleshooting

### Common Issues
1. **Database Errors**: Check SQLite file permissions
2. **Image Loading**: Verify internet connection for player photos
3. **Session Issues**: Clear browser cookies and cache
4. **Admin Access**: Ensure proper user permissions

### Debug Mode
- Set `debug=True` in `dream.py` for development
- Check console logs for error messages
- Use browser developer tools for frontend issues

## 📝 License

This project is licensed under the MIT License - see the LICENSE file for details.

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests if applicable
5. Submit a pull request

## 📞 Support

For support and questions:
- Create an issue in the repository
- Contact the development team
- Check the documentation

## 🔮 Future Enhancements

### Planned Features
- **Real-time Match Updates**: Live score integration
- **Advanced Analytics**: Detailed performance metrics
- **Social Features**: Team sharing and competitions
- **Mobile App**: Native mobile application
- **API Integration**: Third-party cricket data APIs

### Technical Improvements
- **Caching**: Redis for improved performance
- **Microservices**: Scalable architecture
- **Machine Learning**: Enhanced prediction algorithms
- **Real-time Updates**: WebSocket integration

---

**Built with ❤️ for cricket fans and fantasy sports enthusiasts!**
