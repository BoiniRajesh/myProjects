#!/usr/bin/env python3
"""
Test script for IPL Dream11 Team Predictor
This script tests the basic functionality of the application
"""

import os
import sys
from database import DatabaseManager

def test_database_initialization():
    """Test database initialization and sample data insertion"""
    print("Testing database initialization...")
    
    try:
        # Initialize database
        db = DatabaseManager()
        print("[OK] Database initialized successfully")
        
        # Test user creation
        test_email = "test@example.com"
        test_password = "testpassword123"
        test_pan = "ABCDE1234F"
        test_aadhaar = "123456789012"
        test_address = "Test Address, Test City"
        test_gender = "Male"
        
        # Create test user
        success = db.create_user(
            test_email, test_password, test_pan, 
            test_aadhaar, test_address, test_gender
        )
        
        if success:
            print("[OK] Test user created successfully")
        else:
            print("[WARN] Test user already exists (this is expected on subsequent runs)")
        
        # Test authentication
        user = db.authenticate_user(test_email, test_password)
        if user:
            print("[OK] User authentication working")
        else:
            print("[ERROR] User authentication failed")
            return False
        
        # Test teams retrieval
        teams = db.get_all_teams()
        if teams and len(teams) > 0:
            print(f"[OK] {len(teams)} teams loaded successfully")
        else:
            print("[ERROR] No teams found")
            return False
        
        # Test matches retrieval
        matches = db.get_all_matches()
        if matches and len(matches) > 0:
            print(f"[OK] {len(matches)} matches loaded successfully")
        else:
            print("[ERROR] No matches found")
            return False
        
        # Test players retrieval
        if len(teams) >= 2:
            players = db.get_players_by_teams(teams[0]['id'], teams[1]['id'])
            if players and len(players) > 0:
                print(f"[OK] {len(players)} players loaded for test teams")
            else:
                print("[ERROR] No players found for test teams")
                return False
        
        print("\n[SUCCESS] All database tests passed!")
        return True
        
    except Exception as e:
        print(f"[ERROR] Database test failed: {str(e)}")
        return False

def test_imports():
    """Test if all required modules can be imported"""
    print("Testing imports...")
    
    try:
        import flask
        print("[OK] Flask imported successfully")
        
        import pandas
        print("[OK] Pandas imported successfully")
        
        import numpy
        print("[OK] NumPy imported successfully")
        
        import requests
        print("[OK] Requests imported successfully")
        
        from bs4 import BeautifulSoup
        print("[OK] BeautifulSoup imported successfully")
        
        from werkzeug.security import generate_password_hash, check_password_hash
        print("[OK] Werkzeug security imported successfully")
        
        print("[OK] All imports successful!")
        return True
        
    except ImportError as e:
        print(f"[ERROR] Import failed: {str(e)}")
        return False

def main():
    """Run all tests"""
    print("=" * 50)
    print("IPL Dream11 Team Predictor - Test Suite")
    print("=" * 50)
    
    # Test imports
    if not test_imports():
        print("\n[ERROR] Import tests failed. Please install required dependencies.")
        print("Run: pip install -r requirements.txt")
        return False
    
    print()
    
    # Test database
    if not test_database_initialization():
        print("\n[ERROR] Database tests failed.")
        return False
    
    print("\n" + "=" * 50)
    print("[SUCCESS] All tests passed! The application is ready to run.")
    print("=" * 50)
    print("\nTo start the application:")
    print("  python dream.py")
    print("\nThen open your browser and go to:")
    print("  http://localhost:5000")
    print("\nDefault admin credentials:")
    print("  Email: admin@iplpredictor.com")
    print("  Password: admin123")
    
    return True

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)
