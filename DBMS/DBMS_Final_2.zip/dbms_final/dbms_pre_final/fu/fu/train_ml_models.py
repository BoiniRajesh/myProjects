"""
Training script for IPL Dream11 ML Models
Run this script to train the machine learning models for player performance prediction.
"""

import os
import sys
from ml_models import IPLMLPredictor

def main():
    """Main training function"""
    print("=" * 60)
    print("IPL Dream11 ML Models Training")
    print("=" * 60)
    
    # Initialize predictor
    predictor = IPLMLPredictor()
    
    # Check if data is available
    if predictor.byb_data.empty or predictor.match_data.empty:
        print("Error: No data available for training!")
        print("Please ensure the following files exist:")
        print("- IPl Ball-by-Ball 2008-2023.csv")
        print("- IPL Mathces 2008-2023.csv")
        return
    
    print(f"Data loaded successfully:")
    print(f"- Ball-by-ball data: {len(predictor.byb_data)} records")
    print(f"- Match data: {len(predictor.match_data)} records")
    print()
    
    # Train models
    try:
        predictor.train_models()
        print("\n" + "=" * 60)
        print("Training completed successfully!")
        print("=" * 60)
        
        # Test prediction
        print("\nTesting prediction...")
        test_players = ['Virat Kohli', 'MS Dhoni', 'Rohit Sharma']
        for player in test_players:
            prediction = predictor.predict_player_performance(player)
            print(f"{player}: {prediction:.2f} predicted points")
        
    except Exception as e:
        print(f"Error during training: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    main()
