import sqlite3
import hashlib
from datetime import datetime
from werkzeug.security import generate_password_hash, check_password_hash

class DatabaseManager:
    def __init__(self, db_path='users.db'):
        self.db_path = db_path
        self.init_database()
    
    def init_database(self):
        """Initialize the database with all required tables"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Users table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                email TEXT UNIQUE NOT NULL,
                password_hash TEXT NOT NULL,
                pan TEXT NOT NULL,
                aadhaar TEXT NOT NULL,
                address TEXT NOT NULL,
                gender TEXT NOT NULL,
                referral TEXT,
                is_admin BOOLEAN DEFAULT FALSE,
                is_active BOOLEAN DEFAULT TRUE,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        # Teams table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS teams (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                short_name TEXT NOT NULL,
                logo_url TEXT,
                is_active BOOLEAN DEFAULT TRUE,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        # Players table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS players (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                team_id INTEGER,
                position TEXT NOT NULL,
                price REAL NOT NULL,
                image_url TEXT,
                is_active BOOLEAN DEFAULT TRUE,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (team_id) REFERENCES teams (id)
            )
        ''')
        
        # Matches table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS matches (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                team1_id INTEGER,
                team2_id INTEGER,
                match_date DATE NOT NULL,
                venue TEXT NOT NULL,
                is_active BOOLEAN DEFAULT TRUE,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (team1_id) REFERENCES teams (id),
                FOREIGN KEY (team2_id) REFERENCES teams (id)
            )
        ''')
        
        # Match selections table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS match_selections (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                match_id INTEGER,
                selected_players TEXT NOT NULL,
                captain_id INTEGER,
                vice_captain_id INTEGER,
                total_points INTEGER DEFAULT 0,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users (id),
                FOREIGN KEY (match_id) REFERENCES matches (id),
                FOREIGN KEY (captain_id) REFERENCES players (id),
                FOREIGN KEY (vice_captain_id) REFERENCES players (id)
            )
        ''')
        
        # Selected players table (for detailed tracking)
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS selected_players (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                match_selection_id INTEGER,
                player_id INTEGER,
                is_captain BOOLEAN DEFAULT FALSE,
                is_vice_captain BOOLEAN DEFAULT FALSE,
                points INTEGER DEFAULT 0,
                FOREIGN KEY (match_selection_id) REFERENCES match_selections (id),
                FOREIGN KEY (player_id) REFERENCES players (id)
            )
        ''')
        
        conn.commit()
        conn.close()
        
        # Insert sample data
        self.insert_sample_data()
    
    def insert_sample_data(self):
        """Insert sample IPL teams and players data"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Check if data already exists
        cursor.execute("SELECT COUNT(*) FROM teams")
        if cursor.fetchone()[0] > 0:
            conn.close()
            return
        
        # Insert IPL teams
        teams = [
            ('Mumbai Indians', 'MI', 'https://upload.wikimedia.org/wikipedia/en/thumb/8/8f/Mumbai_Indians_Logo.svg/1200px-Mumbai_Indians_Logo.svg.png'),
            ('Chennai Super Kings', 'CSK', 'https://upload.wikimedia.org/wikipedia/en/thumb/2/2b/Chennai_Super_Kings_Logo.svg/1200px-Chennai_Super_Kings_Logo.svg.png'),
            ('Royal Challengers Bangalore', 'RCB', 'https://upload.wikimedia.org/wikipedia/en/thumb/2/2a/Royal_Challengers_Bangalore_2020.svg/1200px-Royal_Challengers_Bangalore_2020.svg.png'),
            ('Kolkata Knight Riders', 'KKR', 'https://upload.wikimedia.org/wikipedia/en/thumb/4/4c/Kolkata_Knight_Riders_Logo.svg/1200px-Kolkata_Knight_Riders_Logo.svg.png'),
            ('Delhi Capitals', 'DC', 'https://upload.wikimedia.org/wikipedia/en/thumb/d/dc/Delhi_Capitals_Logo.svg/1200px-Delhi_Capitals_Logo.svg.png'),
            ('Punjab Kings', 'PBKS', 'https://upload.wikimedia.org/wikipedia/en/thumb/d/df/Punjab_Kings_Logo.svg/1200px-Punjab_Kings_Logo.svg.png'),
            ('Rajasthan Royals', 'RR', 'https://upload.wikimedia.org/wikipedia/en/thumb/6/60/Rajasthan_Royals_Logo.svg/1200px-Rajasthan_Royals_Logo.svg.png'),
            ('Sunrisers Hyderabad', 'SRH', 'https://upload.wikimedia.org/wikipedia/en/thumb/8/81/Sunrisers_Hyderabad.svg/1200px-Sunrisers_Hyderabad.svg.png')
        ]
        
        cursor.executemany(
            "INSERT INTO teams (name, short_name, logo_url) VALUES (?, ?, ?)",
            teams
        )
        
        # Insert sample players
        players = [
            # Mumbai Indians
            (1, 'Rohit Sharma', 'Batsman', 10.5, 'https://ui-avatars.com/api/?name=Rohit+Sharma&size=150&background=667eea&color=fff&bold=true'),
            (1, 'Jasprit Bumrah', 'Bowler', 9.0, 'https://ui-avatars.com/api/?name=Jasprit+Bumrah&size=150&background=667eea&color=fff&bold=true'),
            (1, 'Suryakumar Yadav', 'Batsman', 9.5, 'https://ui-avatars.com/api/?name=Suryakumar+Yadav&size=150&background=667eea&color=fff&bold=true'),
            (1, 'Hardik Pandya', 'All-rounder', 9.0, 'https://ui-avatars.com/api/?name=Hardik+Pandya&size=150&background=667eea&color=fff&bold=true'),
            (1, 'Kieron Pollard', 'All-rounder', 8.5, 'https://ui-avatars.com/api/?name=Kieron+Pollard&size=150&background=667eea&color=fff&bold=true'),
            
            # Chennai Super Kings
            (2, 'MS Dhoni', 'Wicket-keeper', 9.5, 'https://ui-avatars.com/api/?name=MS+Dhoni&size=150&background=ffd700&color=000&bold=true'),
            (2, 'Ravindra Jadeja', 'All-rounder', 9.0, 'https://ui-avatars.com/api/?name=Ravindra+Jadeja&size=150&background=ffd700&color=000&bold=true'),
            (2, 'Faf du Plessis', 'Batsman', 9.0, 'https://ui-avatars.com/api/?name=Faf+du+Plessis&size=150&background=ffd700&color=000&bold=true'),
            (2, 'Deepak Chahar', 'Bowler', 8.0, 'https://ui-avatars.com/api/?name=Deepak+Chahar&size=150&background=ffd700&color=000&bold=true'),
            (2, 'Ruturaj Gaikwad', 'Batsman', 8.5, 'https://ui-avatars.com/api/?name=Ruturaj+Gaikwad&size=150&background=ffd700&color=000&bold=true'),
            
            # Royal Challengers Bangalore
            (3, 'Virat Kohli', 'Batsman', 10.0, 'https://ui-avatars.com/api/?name=Virat+Kohli&size=150&background=ff0000&color=fff&bold=true'),
            (3, 'AB de Villiers', 'Batsman', 9.5, 'https://ui-avatars.com/api/?name=AB+de+Villiers&size=150&background=ff0000&color=fff&bold=true'),
            (3, 'Yuzvendra Chahal', 'Bowler', 8.5, 'https://ui-avatars.com/api/?name=Yuzvendra+Chahal&size=150&background=ff0000&color=fff&bold=true'),
            (3, 'Glenn Maxwell', 'All-rounder', 9.0, 'https://ui-avatars.com/api/?name=Glenn+Maxwell&size=150&background=ff0000&color=fff&bold=true'),
            (3, 'Mohammed Siraj', 'Bowler', 8.0, 'https://ui-avatars.com/api/?name=Mohammed+Siraj&size=150&background=ff0000&color=fff&bold=true'),
            
            # Kolkata Knight Riders
            (4, 'Eoin Morgan', 'Batsman', 9.0, 'https://ui-avatars.com/api/?name=Eoin+Morgan&size=150&background=9c27b0&color=fff&bold=true'),
            (4, 'Andre Russell', 'All-rounder', 9.5, 'https://ui-avatars.com/api/?name=Andre+Russell&size=150&background=9c27b0&color=fff&bold=true'),
            (4, 'Sunil Narine', 'All-rounder', 8.5, 'https://ui-avatars.com/api/?name=Sunil+Narine&size=150&background=9c27b0&color=fff&bold=true'),
            (4, 'Shubman Gill', 'Batsman', 8.5, 'https://ui-avatars.com/api/?name=Shubman+Gill&size=150&background=9c27b0&color=fff&bold=true'),
            (4, 'Varun Chakravarthy', 'Bowler', 8.0, 'https://ui-avatars.com/api/?name=Varun+Chakravarthy&size=150&background=9c27b0&color=fff&bold=true'),
            
            # Delhi Capitals
            (5, 'Rishabh Pant', 'Wicket-keeper', 9.0, 'https://ui-avatars.com/api/?name=Rishabh+Pant&size=150&background=2196f3&color=fff&bold=true'),
            (5, 'Shikhar Dhawan', 'Batsman', 9.0, 'https://ui-avatars.com/api/?name=Shikhar+Dhawan&size=150&background=2196f3&color=fff&bold=true'),
            (5, 'Kagiso Rabada', 'Bowler', 9.0, 'https://ui-avatars.com/api/?name=Kagiso+Rabada&size=150&background=2196f3&color=fff&bold=true'),
            (5, 'Prithvi Shaw', 'Batsman', 8.5, 'https://ui-avatars.com/api/?name=Prithvi+Shaw&size=150&background=2196f3&color=fff&bold=true'),
            (5, 'Axar Patel', 'All-rounder', 8.0, 'https://ui-avatars.com/api/?name=Axar+Patel&size=150&background=2196f3&color=fff&bold=true'),
            
            # Punjab Kings
            (6, 'KL Rahul', 'Wicket-keeper', 9.5, 'https://ui-avatars.com/api/?name=KL+Rahul&size=150&background=ff9800&color=fff&bold=true'),
            (6, 'Chris Gayle', 'Batsman', 9.0, 'https://ui-avatars.com/api/?name=Chris+Gayle&size=150&background=ff9800&color=fff&bold=true'),
            (6, 'Mohammed Shami', 'Bowler', 8.5, 'https://ui-avatars.com/api/?name=Mohammed+Shami&size=150&background=ff9800&color=fff&bold=true'),
            (6, 'Mayank Agarwal', 'Batsman', 8.5, 'https://ui-avatars.com/api/?name=Mayank+Agarwal&size=150&background=ff9800&color=fff&bold=true'),
            (6, 'Ravi Bishnoi', 'Bowler', 7.5, 'https://ui-avatars.com/api/?name=Ravi+Bishnoi&size=150&background=ff9800&color=fff&bold=true'),
            
            # Rajasthan Royals
            (7, 'Sanju Samson', 'Wicket-keeper', 8.5, 'https://ui-avatars.com/api/?name=Sanju+Samson&size=150&background=e91e63&color=fff&bold=true'),
            (7, 'Jos Buttler', 'Wicket-keeper', 9.0, 'https://ui-avatars.com/api/?name=Jos+Buttler&size=150&background=e91e63&color=fff&bold=true'),
            (7, 'Ben Stokes', 'All-rounder', 9.0, 'https://ui-avatars.com/api/?name=Ben+Stokes&size=150&background=e91e63&color=fff&bold=true'),
            (7, 'Jofra Archer', 'Bowler', 8.5, 'https://ui-avatars.com/api/?name=Jofra+Archer&size=150&background=e91e63&color=fff&bold=true'),
            (7, 'Rahul Tewatia', 'All-rounder', 7.5, 'https://ui-avatars.com/api/?name=Rahul+Tewatia&size=150&background=e91e63&color=fff&bold=true'),
            
            # Sunrisers Hyderabad
            (8, 'David Warner', 'Batsman', 9.5, 'https://ui-avatars.com/api/?name=David+Warner&size=150&background=ff5722&color=fff&bold=true'),
            (8, 'Kane Williamson', 'Batsman', 9.0, 'https://ui-avatars.com/api/?name=Kane+Williamson&size=150&background=ff5722&color=fff&bold=true'),
            (8, 'Rashid Khan', 'Bowler', 9.0, 'https://ui-avatars.com/api/?name=Rashid+Khan&size=150&background=ff5722&color=fff&bold=true'),
            (8, 'Bhuvneshwar Kumar', 'Bowler', 8.5, 'https://ui-avatars.com/api/?name=Bhuvneshwar+Kumar&size=150&background=ff5722&color=fff&bold=true'),
            (8, 'Manish Pandey', 'Batsman', 8.0, 'https://ui-avatars.com/api/?name=Manish+Pandey&size=150&background=ff5722&color=fff&bold=true')
        ]
        
        cursor.executemany(
            "INSERT INTO players (team_id, name, position, price, image_url) VALUES (?, ?, ?, ?, ?)",
            players
        )
        
        # Insert sample matches
        matches = [
            (1, 2, '2024-03-22', 'Wankhede Stadium, Mumbai'),
            (3, 4, '2024-03-23', 'M. Chinnaswamy Stadium, Bangalore'),
            (5, 6, '2024-03-24', 'Arun Jaitley Stadium, Delhi'),
            (7, 8, '2024-03-25', 'Sawai Mansingh Stadium, Jaipur'),
            (1, 3, '2024-03-26', 'Wankhede Stadium, Mumbai'),
            (2, 4, '2024-03-27', 'M. A. Chidambaram Stadium, Chennai'),
            (5, 7, '2024-03-28', 'Arun Jaitley Stadium, Delhi'),
            (6, 8, '2024-03-29', 'Punjab Cricket Association Stadium, Mohali')
        ]
        
        cursor.executemany(
            "INSERT INTO matches (team1_id, team2_id, match_date, venue) VALUES (?, ?, ?, ?)",
            matches
        )
        
        # Create admin user
        admin_password = generate_password_hash('admin123')
        cursor.execute(
            "INSERT INTO users (email, password_hash, pan, aadhaar, address, gender, is_admin) VALUES (?, ?, ?, ?, ?, ?, ?)",
            ('admin@iplpredictor.com', admin_password, 'ABCDE1234F', '123456789012', 'Admin Address', 'Male', True)
        )
        
        conn.commit()
        conn.close()
    
    def get_connection(self):
        """Get database connection"""
        return sqlite3.connect(self.db_path)
    
    def create_user(self, email, password, pan, aadhaar, address, gender, referral=None):
        """Create a new user"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        try:
            password_hash = generate_password_hash(password)
            cursor.execute(
                "INSERT INTO users (email, password_hash, pan, aadhaar, address, gender, referral) VALUES (?, ?, ?, ?, ?, ?, ?)",
                (email, password_hash, pan, aadhaar, address, gender, referral)
            )
            conn.commit()
            return True
        except sqlite3.IntegrityError:
            return False
        finally:
            conn.close()
    
    def authenticate_user(self, email, password):
        """Authenticate user login"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        cursor.execute("SELECT id, password_hash, is_admin, is_active FROM users WHERE email = ?", (email,))
        user = cursor.fetchone()
        
        if user and check_password_hash(user[1], password) and user[3]:  # Check if user is active
            return {'id': user[0], 'email': email, 'is_admin': user[2]}
        
        conn.close()
        return None
    
    def get_user_by_id(self, user_id):
        """Get user details by ID"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        cursor.execute("SELECT id, email, pan, aadhaar, address, gender, referral, is_admin, is_active FROM users WHERE id = ?", (user_id,))
        user = cursor.fetchone()
        
        if user:
            return {
                'id': user[0],
                'email': user[1],
                'pan': user[2],
                'aadhaar': user[3],
                'address': user[4],
                'gender': user[5],
                'referral': user[6],
                'is_admin': user[7],
                'is_active': user[8]
            }
        
        conn.close()
        return None
    
    def get_all_teams(self):
        """Get all active teams"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        cursor.execute("SELECT id, name, short_name, logo_url FROM teams WHERE is_active = TRUE")
        teams = cursor.fetchall()
        
        conn.close()
        return [{'id': team[0], 'name': team[1], 'short_name': team[2], 'logo_url': team[3]} for team in teams]
    
    def get_players_by_teams(self, team1_id, team2_id):
        """Get players from two specific teams"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        cursor.execute("""
            SELECT p.id, p.name, p.position, p.price, p.image_url, t.name as team_name, t.short_name
            FROM players p
            JOIN teams t ON p.team_id = t.id
            WHERE p.team_id IN (?, ?) AND p.is_active = TRUE
            ORDER BY t.name, p.position, p.name
        """, (team1_id, team2_id))
        
        players = cursor.fetchall()
        conn.close()
        
        return [{
            'id': player[0],
            'name': player[1],
            'position': player[2],
            'price': player[3],
            'image_url': player[4],
            'team_name': player[5],
            'team_short': player[6]
        } for player in players]

    def get_players_by_ids(self, ids):
        """Get player details for a list of player IDs."""
        if not ids:
            return []
        placeholders = ','.join('?' for _ in ids)
        query = f"SELECT p.id, p.name, p.position, p.price, p.image_url, t.name as team_name, t.short_name FROM players p JOIN teams t ON p.team_id = t.id WHERE p.id IN ({placeholders})"
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute(query, tuple(ids))
        players = cursor.fetchall()
        conn.close()
        return [{
            'id': player[0],
            'name': player[1],
            'position': player[2],
            'price': player[3],
            'image_url': player[4],
            'team_name': player[5],
            'team_short': player[6]
        } for player in players]

    def get_player_id_by_name_and_team(self, name, team_name):
        """Return the DB player id for a given player name and team name, or None if not found."""
        try:
            conn = self.get_connection()
            cursor = conn.cursor()

            # Try exact match first
            cursor.execute("""
                SELECT p.id, p.name FROM players p
                JOIN teams t ON p.team_id = t.id
                WHERE p.name = ? AND t.name = ?
            """, (name, team_name))
            row = cursor.fetchone()
            if row:
                return row[0]

            # Fetch all players for the team and attempt fuzzy matching
            cursor.execute("""
                SELECT p.id, p.name FROM players p
                JOIN teams t ON p.team_id = t.id
                WHERE t.name = ?
            """, (team_name,))
            candidates = cursor.fetchall()
            conn.close()

            # Normalize function
            import re
            def norm(s):
                return re.sub(r'[^a-z0-9]', '', s.lower())

            target = norm(name)
            best_id = None
            best_score = 0.0
            from difflib import SequenceMatcher
            for pid, pname in candidates:
                score = SequenceMatcher(None, target, norm(pname)).ratio()
                if score > best_score:
                    best_score = score
                    best_id = pid

            # Accept match if similarity is reasonably high
            if best_score >= 0.6:
                return best_id
            return None
        except Exception:
            try:
                conn.close()
            except Exception:
                pass
            return None
    
    def get_all_matches(self):
        """Get all active matches"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        cursor.execute("""
            SELECT m.id, m.match_date, m.venue, 
                   t1.name as team1_name, t1.short_name as team1_short,
                   t2.name as team2_name, t2.short_name as team2_short
            FROM matches m
            JOIN teams t1 ON m.team1_id = t1.id
            JOIN teams t2 ON m.team2_id = t2.id
            WHERE m.is_active = TRUE
            ORDER BY m.match_date
        """)
        
        matches = cursor.fetchall()
        conn.close()
        
        return [{
            'id': match[0],
            'match_date': match[1],
            'venue': match[2],
            'team1_name': match[3],
            'team1_short': match[4],
            'team2_name': match[5],
            'team2_short': match[6]
        } for match in matches]
    
    def save_match_selection(self, user_id, match_id, selected_players, captain_id, vice_captain_id, total_cost=0, total_points=0):
        """Save user's match selection"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        try:
            # Ensure selected_players is a Python list (it may be passed as JSON string)
            import json
            if isinstance(selected_players, str):
                try:
                    parsed = json.loads(selected_players)
                except Exception:
                    parsed = []
            else:
                parsed = list(selected_players) if selected_players is not None else []

            # Store the JSON string in match_selections
            import json as _json
            selected_players_json = _json.dumps(parsed)

            # Ensure total_cost and total_points columns exist (this is a safe alter-if-needed)
            try:
                cursor.execute("ALTER TABLE match_selections ADD COLUMN total_cost REAL DEFAULT 0")
            except Exception:
                pass
            try:
                cursor.execute("ALTER TABLE match_selections ADD COLUMN total_points REAL DEFAULT 0")
            except Exception:
                pass

            cursor.execute("""
                INSERT INTO match_selections (user_id, match_id, selected_players, captain_id, vice_captain_id, total_cost, total_points)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            """, (user_id, match_id, selected_players_json, captain_id, vice_captain_id, total_cost, total_points))

            selection_id = cursor.lastrowid

            # Save individual player selections.
            # parsed may be list of ints (player ids) or list of dicts (player objects)
            for player in parsed:
                pid = None
                is_captain_flag = False
                is_vice_flag = False

                if isinstance(player, dict):
                    # Try to map by name/team to DB id
                    name = player.get('name')
                    team_name = player.get('team_name')
                    try:
                        pid = self.get_player_id_by_name_and_team(name, team_name)
                    except Exception:
                        pid = None
                    # Check if client set captain/vice flags
                    is_captain_flag = bool(player.get('is_captain', False))
                    is_vice_flag = bool(player.get('is_vice_captain', False))
                else:
                    try:
                        pid = int(player)
                    except Exception:
                        pid = None

                # If captain/vice DB ids were provided directly, reconcile
                if pid is not None:
                    if captain_id and pid == captain_id:
                        is_captain_flag = True
                    if vice_captain_id and pid == vice_captain_id:
                        is_vice_flag = True

                if pid is None:
                    # Can't map to DB id; skip inserting into selected_players table but leave JSON snapshot in match_selections
                    continue

                cursor.execute("""
                    INSERT INTO selected_players (match_selection_id, player_id, is_captain, is_vice_captain)
                    VALUES (?, ?, ?, ?)
                """, (selection_id, pid, is_captain_flag, is_vice_flag))
            
            conn.commit()
            return selection_id
        except Exception as e:
            conn.rollback()
            return None
        finally:
            conn.close()
    
    def get_user_history(self, user_id):
        """Get user's match selection history"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        cursor.execute("""
            SELECT ms.id, ms.created_at, ms.selected_players, ms.captain_id, ms.vice_captain_id, ms.total_points,
                   m.match_date, m.venue,
                   t1.name as team1_name, t1.short_name as team1_short,
                   t2.name as team2_name, t2.short_name as team2_short
            FROM match_selections ms
            JOIN matches m ON ms.match_id = m.id
            JOIN teams t1 ON m.team1_id = t1.id
            JOIN teams t2 ON m.team2_id = t2.id
            WHERE ms.user_id = ?
            ORDER BY ms.created_at DESC
        """, (user_id,))
        
        history = cursor.fetchall()
        conn.close()
        
        results = []
        import json
        for h in history:
            sel_json = h[2]
            total_points = h[5] if h[5] is not None else 0
            total_cost = 0
            player_summaries = []

            try:
                parsed = json.loads(sel_json) if sel_json else []
            except Exception:
                parsed = []

            # parsed may be list of dicts or list of ints (DB ids)
            if parsed and isinstance(parsed[0], dict):
                # compute totals from snapshot
                for p in parsed:
                    pts = p.get('fantasy_points') or 0
                    total_points = total_points or 0
                    total_cost += p.get('price', 0) or 0
                    player_summaries.append({'name': p.get('name'), 'fantasy_points': round(pts,1)})
                # if DB total_points not set, sum fantasy_points
                if (h[5] is None or h[5] == 0) and player_summaries:
                    try:
                        total_points = sum(p['fantasy_points'] for p in player_summaries)
                    except Exception:
                        pass
            elif parsed and isinstance(parsed[0], int):
                # try to fetch DB players for names/prices
                try:
                    players = self.get_players_by_ids(parsed)
                    for p in players:
                        player_summaries.append({'name': p['name'], 'fantasy_points': 0})
                except Exception:
                    pass

            results.append({
                'id': h[0],
                'created_at': h[1],
                'selected_players': sel_json,
                'player_summaries': player_summaries,
                'captain_id': h[3],
                'vice_captain_id': h[4],
                'total_points': total_points or 0,
                'match_date': h[6],
                'venue': h[7],
                'team1_name': h[8],
                'team1_short': h[9],
                'team2_name': h[10],
                'team2_short': h[11],
                'total_cost': total_cost
            })

        return results
    
    def get_all_users(self):
        """Get all users for admin dashboard"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        cursor.execute("SELECT id, email, is_admin, is_active, created_at FROM users ORDER BY created_at DESC")
        users = cursor.fetchall()
        
        conn.close()
        return [{
            'id': user[0],
            'email': user[1],
            'is_admin': user[2],
            'is_active': user[3],
            'created_at': user[4]
        } for user in users]
    
    def toggle_user_status(self, user_id, is_active):
        """Toggle user active status"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        cursor.execute("UPDATE users SET is_active = ? WHERE id = ?", (is_active, user_id))
        conn.commit()
        conn.close()
    
    def toggle_team_status(self, team_id, is_active):
        """Toggle team active status"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        cursor.execute("UPDATE teams SET is_active = ? WHERE id = ?", (is_active, team_id))
        conn.commit()
        conn.close()
