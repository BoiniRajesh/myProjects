#!/usr/bin/env python3
"""
Debug script to check database content
"""

from database import DatabaseManager

def main():
    db = DatabaseManager()
    
    # Check teams
    teams = db.get_all_teams()
    print(f"Total teams: {len(teams)}")
    for team in teams[:3]:
        print(f"- {team['name']} ({team['short_name']})")
    
    # Check players for first two teams
    if len(teams) >= 2:
        players = db.get_players_by_teams(teams[0]['id'], teams[1]['id'])
        print(f"\nPlayers for {teams[0]['name']} vs {teams[1]['name']}: {len(players)}")
        
        for player in players[:10]:  # Show first 10 players
            print(f"- {player['name']} ({player['position']}) - Rs{player['price']} - {player['team_name']}")
            print(f"  Image URL: {player['image_url']}")
    
    # Check matches
    matches = db.get_all_matches()
    print(f"\nTotal matches: {len(matches)}")
    for match in matches[:3]:
        print(f"- {match['team1_name']} vs {match['team2_name']} on {match['match_date']}")

if __name__ == "__main__":
    main()
