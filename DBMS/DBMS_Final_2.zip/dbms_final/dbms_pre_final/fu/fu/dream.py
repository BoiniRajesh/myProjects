from flask import Flask, render_template, request, redirect, url_for, session, flash, jsonify
import pandas as pd
import numpy as np
import requests
from bs4 import BeautifulSoup
import json
import random
import os
from database import DatabaseManager
from ml_models import get_ml_predictor

app = Flask(__name__)
app.secret_key = 'your-secret-key-change-this-in-production'

# Initialize database
db = DatabaseManager()

# Get the directory of the current script
script_dir = os.path.dirname(os.path.abspath(__file__))

# Reading files (using absolute paths with forward slashes)
try:
    byb = pd.read_csv(os.path.join(script_dir, 'IPl Ball-by-Ball 2008-2023.csv'))
    match = pd.read_csv(os.path.join(script_dir, 'IPL Mathces 2008-2023.csv'))
    print("Data files loaded successfully")
except Exception as e:
    print(f"Error loading data files: {e}")
    byb = pd.DataFrame()
    match = pd.DataFrame()

# Team mapping for Excel files
TEAM_MAPPING = {
    'Mumbai Indians': 'mi',
    'Chennai Super Kings': 'csk', 
    'Royal Challengers Bangalore': 'rcb',
    'Kolkata Knight Riders': 'kkr',
    'Delhi Capitals': 'dc',
    'Punjab Kings': 'pbks',
    'Rajasthan Royals': 'rr',
    'Sunrisers Hyderabad': 'srh',
    'Gujarat Titans': 'gt',
    'Lucknow Super Giants': 'lsg'
}

def load_team_players_from_excel(team_name):
    """Load players from Excel file for a specific team"""
    try:
        team_short = TEAM_MAPPING.get(team_name, team_name.lower().replace(' ', ''))
        excel_path = os.path.join(script_dir, 'Teams', f'{team_short}.xlsx')
        
        if os.path.exists(excel_path):
            df = pd.read_excel(excel_path)
            players = []
            for _, row in df.iterrows():
                # Ensure all required fields are present
                player_data = {
                    'id': len(players) + 1,  # Simple ID generation
                    'name': str(row['player_name']),
                    'position': str(row.get('position', 'Batsman')),
                    'price': float(row.get('price', 8.0)),
                    'team_name': team_name,
                    'image_url': f"https://ui-avatars.com/api/?name={str(row['player_name']).replace(' ', '+')}&size=150&background=667eea&color=fff&bold=true"
                }
                players.append(player_data)
            return players
        else:
            print(f"Excel file not found: {excel_path}")
            return []
    except Exception as e:
        print(f"Error loading team {team_name}: {e}")
        return []

def get_player_image_url(player_name):
    """Get player image URL from web search"""
    try:
        # Use a more reliable approach with multiple fallbacks
        search_queries = [
            f"{player_name} IPL cricket player",
            f"{player_name} cricket player photo",
            f"{player_name} IPL 2024"
        ]
        
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
        }
        
        for query in search_queries:
            try:
                search_url = f"https://www.google.com/search?q={query}&tbm=isch"
                response = requests.get(search_url, headers=headers, timeout=5)
                soup = BeautifulSoup(response.content, 'html.parser')
                
                # Find images with better filtering
                img_tags = soup.find_all('img')
                for img in img_tags:
                    src = img.get('src') or img.get('data-src')
                    if src and src.startswith('http') and not any(skip in src.lower() for skip in ['google', 'gstatic', 'youtube', 'facebook', 'twitter']):
                        return src
            except:
                continue
        
        # Fallback to a more reliable placeholder service
        return f"https://ui-avatars.com/api/?name={player_name.replace(' ', '+')}&size=150&background=667eea&color=fff&bold=true"
    except:
        return f"https://ui-avatars.com/api/?name={player_name.replace(' ', '+')}&size=150&background=667eea&color=fff&bold=true"

# Fantasy Points Configuration
Batsman_points = {'Run': 1, 'bFour': 1, 'bSix': 2, '30Runs': 4,
                  'Half_century': 8, 'Century': 16, 'Duck': -2, '170sr': 6,
                  '150sr': 4, '130sr': 2, '70sr': -2, '60sr': -4, '50sr': -6}

Bowling_points = {'Wicket': 25, 'LBW_Bowled': 8, '3W': 4, '4W': 8,
                  '5W': 16, 'Maiden': 12, '5rpo': 6, '6rpo': 4, '7rpo': 2, '10rpo': -2,
                  '11rpo': -4, '12rpo': -6}

Fielding_points = {'Catch': 8, '3Cath': 4, 'Stumping': 12, 'RunOutD': 12,
                   'RunOutInd': 6}

def calculate_player_fantasy_points(player_name):
    """Calculate fantasy points for a player based on historical performance."""
    try:
        # Collect any match IDs where the player appears as batsman, bowler, or fielder
        player_rows = byb[(byb['batsman'] == player_name) | (byb['bowler'] == player_name) | (byb['fielder'] == player_name)]
        player_matches = player_rows['id'].unique()

        if len(player_matches) == 0:
            # No historical data for player — return 0
            return 0

        total_points = 0.0
        matches_played = len(player_matches)

        for match_id in player_matches:
            match_data = byb[byb['id'] == match_id]

            # Batting contribution (only if the player batted in the match)
            batting = match_data[match_data['batsman'] == player_name]
            if len(batting) > 0:
                runs = int(batting['batsman_runs'].sum())
                fours = len(batting[batting['batsman_runs'] == 4])
                sixes = len(batting[batting['batsman_runs'] == 6])

                total_points += runs + (fours * Batsman_points['bFour']) + (sixes * Batsman_points['bSix'])

                # Milestone points only when batted
                if runs >= 100:
                    total_points += Batsman_points['Century']
                elif runs >= 50:
                    total_points += Batsman_points['Half_century']
                elif runs >= 30:
                    total_points += Batsman_points['30Runs']
                elif runs == 0 and len(batting) > 0:
                    total_points += Batsman_points['Duck']

            # Bowling contribution
            bowling = match_data[match_data['bowler'] == player_name]
            if len(bowling) > 0:
                # is_wicket may be 0/1 or booleans; coerce to int
                wickets = int(bowling['is_wicket'].sum())
                total_points += wickets * Bowling_points['Wicket']

                if wickets >= 5:
                    total_points += Bowling_points['5W']
                elif wickets >= 4:
                    total_points += Bowling_points['4W']
                elif wickets >= 3:
                    total_points += Bowling_points['3W']

                lbw_bowled = bowling[bowling['dismissal_kind'].isin(['lbw', 'bowled'])]
                total_points += len(lbw_bowled) * Bowling_points['LBW_Bowled']

            # Fielding contribution
            catches = len(match_data[(match_data['fielder'] == player_name) & (match_data['dismissal_kind'] == 'caught')])
            stumps = len(match_data[(match_data['fielder'] == player_name) & (match_data['dismissal_kind'] == 'stumped')])
            run_outs_direct = len(match_data[(match_data['fielder'] == player_name) & (match_data['dismissal_kind'] == 'run out')])

            total_points += catches * Fielding_points['Catch']
            total_points += stumps * Fielding_points['Stumping']
            total_points += run_outs_direct * Fielding_points['RunOutInd']

        avg_points = total_points / matches_played if matches_played > 0 else 0
        return round(avg_points, 2)
        
    except Exception as e:
        print(f"Error calculating fantasy points for {player_name}: {e}")
        # On error, return 0 to avoid skewing team selection
        return 0

def get_team_fantasy_points(team_players):
    """Get fantasy points for all players in a team."""
    return {player: calculate_player_fantasy_points(player) for player in team_players}

def get_players_ml(team1, team2, team1_fp):
    """Calculate fantasy points for players using ML predictions."""
    try:
        # Get ML predictor
        ml_predictor = get_ml_predictor()
        
        fantasy_team_players = []
        
        for i in range(len(team1)):
            player_name = team1[i]
            
            # Get opponent team name for context
            opponent_team = team2[0] if team2 else "Unknown"
            
            # Use ML prediction
            predicted_points = ml_predictor.predict_player_performance(
                player_name, 
                opponent_team=opponent_team
            )
            
            # Apply player vs player weights
            total_weight = 1.0
            for opponent in team2:
                weight = ml_predictor.get_player_vs_player_weights(player_name, opponent)
                total_weight *= weight
            
            # Combine ML prediction with recent form
            recent_form_factor = team1_fp.get(player_name, 0) / 10  # Scale recent form
            final_points = predicted_points * total_weight + recent_form_factor
            final_points = round(max(0, final_points), 2)  # Ensure non-negative
            
            fantasy_team_players.append((final_points, player_name))
        
        fantasy_team_players.sort(reverse=True)
        return fantasy_team_players
        
    except Exception as e:
        print(f"ML prediction failed, falling back to manual algorithm: {e}")
        # Fallback to original algorithm
        return get_players_manual(team1, team2, team1_fp)

def get_players_manual(team1, team2, team1_fp):
    """Original manual algorithm as fallback."""
    fantasy_team_players = []

    for i in range(len(team1)):
        unq_ids = byb[byb["batsman"]==team1[i]]['id'].unique()
        mathces_played = len(unq_ids)
        
        bbr = []
        for x in unq_ids:
            bat_run = sum(byb[(byb["batsman"]==team1[i])&(byb['id']==x)]['batsman_runs'])
            bbr.append(bat_run)

        r30,r50,r100 =0,0,0
        for m in bbr:
            if m>=100:
                r100+=1
            elif m>=50:
                r50+=1
            elif m>=30:
                r30+=1
        try:
            catches = len(byb[(byb['fielder']==team1[i]) & (byb['dismissal_kind']=='caught')])/mathces_played
            run_outs = len(byb[(byb['fielder']==team1[i]) & (byb['dismissal_kind']=='run out')])/mathces_played
            extra_points = r30/mathces_played*Batsman_points['30Runs'] +r50/mathces_played*Batsman_points['Half_century'] +r100/mathces_played*Batsman_points['Century'] +catches*Fielding_points['Catch']+run_outs*Fielding_points['RunOutInd']
        except:
            catches, run_outs, extra_points = 0,0,0
        
        # Extra Points for bowlers to be estimated here
        wickets_taken = []
        for x in unq_ids:
            twx = sum(byb[(byb["bowler"]==team1[i]) & (byb['id']==x)]['is_wicket'])
            wickets_taken.append(twx)

        w3,w4,w5 = 0,0,0
        for z in wickets_taken:
            if z>=5:
                w5+=1
            elif z>=4:
                w4+=1
            elif z>=3:
                w3+=1
        try:
            lbws = len((byb[(byb['bowler']==team1[i]) & (byb['dismissal_kind']=='lbw')]))/mathces_played      
            bowled = len((byb[(byb['bowler']==team1[i]) & (byb['dismissal_kind']=='bowled')]))/mathces_played      
            wexp = w3/mathces_played*Bowling_points['3W'] + w4/mathces_played*Bowling_points['4W'] + w5/mathces_played*Bowling_points['5W'] + lbws*Bowling_points['LBW_Bowled'] + bowled*Bowling_points['LBW_Bowled']
        except:
            lbws, bowled, wexp = 0,0,0
        
        ffp = []
        for j in range(len(team2)):
            bat_vs_bowl = byb[(byb["batsman"]==team1[i]) & (byb["bowler"]==team2[j])]
            bowls_played = len(bat_vs_bowl.batsman_runs)
            runs_scored = sum(bat_vs_bowl.batsman_runs)
            fours = len(bat_vs_bowl[bat_vs_bowl['batsman_runs']==4])
            sixes = len(bat_vs_bowl[bat_vs_bowl['batsman_runs']==6])
            wicket = sum(bat_vs_bowl.is_wicket)
            if bowls_played <=6*10 and wicket >=5:
                penalty = -16
            elif bowls_played <=6*8 and wicket >=4:
                penalty = -8
            elif bowls_played <=6*6 and wicket >=3:
                penalty = -4
            else:
                penalty = 0

            try:    
                strike_rate = int(runs_scored/bowls_played*100)
            except: 
                strike_rate = 'NA'            

            bowl_vs_bat = byb[(byb["bowler"]==team1[i]) & (byb["batsman"]==team2[j])]
            wicket_took = sum(bowl_vs_bat.is_wicket)
            fantasy_points1 = runs_scored + fours*Batsman_points['bFour'] + sixes*Batsman_points['bSix'] - wicket*Bowling_points['Wicket'] + wicket_took*Bowling_points['Wicket'] + penalty 
            ffp.append(fantasy_points1)
        sum_ffp = sum(ffp)
        if team1_fp[team1[i]] > 0:
            recent_performace_points = np.log(team1_fp[team1[i]])
        elif team1_fp[team1[i]] <0:
            recent_performace_points = -np.log(abs(team1_fp[team1[i]]))
        else:
            recent_performace_points = 0
        # Trying a new method for recent performancec point
        recent_performace_points = team1_fp[team1[i]]/3
        weight1 = 0.5
        weight2 = 1 - weight1
        final_fantasy_point = (sum_ffp + extra_points + wexp)*weight1 + recent_performace_points*weight2
        final_fantasy_point = round(final_fantasy_point,2)
        fantasy_team_players.append((final_fantasy_point,team1[i]))
        fantasy_team_players.sort(reverse=True)
    return fantasy_team_players

def get_players(team1, team2, team1_fp):
    """Calculate fantasy points for players - now uses ML by default."""
    return get_players_ml(team1, team2, team1_fp)

def calculate_fantasy_points(player_name, position, performance_data=None):
    """Calculate fantasy points for a player based on position and performance"""
    import random
    
    # Base points for different positions
    base_points = {
        'Batsman': 20,
        'Bowler': 25,
        'All-rounder': 30,
        'Wicket-keeper': 25
    }
    
    # Get base points
    points = base_points.get(position, 20)
    
    # Simulate realistic performance based on position
    if position == 'Batsman':
        # Simulate batting performance
        runs = random.randint(5, 85)
        fours = random.randint(0, 8)
        sixes = random.randint(0, 4)
        
        # Basic batting points
        points += runs * Batsman_points['Run']
        points += fours * Batsman_points['bFour']
        points += sixes * Batsman_points['bSix']
        
        # Milestone points
        if runs >= 100:
            points += Batsman_points['Century']
        elif runs >= 50:
            points += Batsman_points['Half_century']
        elif runs >= 30:
            points += Batsman_points['30Runs']
        elif runs == 0:
            points += Batsman_points['Duck']
        
        # Strike rate points (simulated)
        sr = random.randint(80, 180)
        if sr >= 170:
            points += Batsman_points['170sr']
        elif sr >= 150:
            points += Batsman_points['150sr']
        elif sr >= 130:
            points += Batsman_points['130sr']
        elif sr <= 70:
            points += Batsman_points['70sr']
        elif sr <= 60:
            points += Batsman_points['60sr']
        elif sr <= 50:
            points += Batsman_points['50sr']
    
    elif position == 'Bowler':
        # Simulate bowling performance
        wickets = random.randint(0, 5)
        maidens = random.randint(0, 2)
        runs_conceded = random.randint(15, 60)
        overs = random.randint(2, 4)
        
        # Wicket points
        points += wickets * Bowling_points['Wicket']
        
        # Wicket haul bonuses
        if wickets >= 5:
            points += Bowling_points['5W']
        elif wickets >= 4:
            points += Bowling_points['4W']
        elif wickets >= 3:
            points += Bowling_points['3W']
        
        # Maiden overs
        points += maidens * Bowling_points['Maiden']
        
        # Economy rate points
        if overs > 0:
            economy = runs_conceded / overs
            if economy <= 5:
                points += Bowling_points['5rpo']
            elif economy <= 6:
                points += Bowling_points['6rpo']
            elif economy <= 7:
                points += Bowling_points['7rpo']
            elif economy >= 10:
                points += Bowling_points['10rpo']
            elif economy >= 11:
                points += Bowling_points['11rpo']
            elif economy >= 12:
                points += Bowling_points['12rpo']
    
    elif position == 'All-rounder':
        # Simulate all-rounder performance (batting + bowling)
        runs = random.randint(10, 70)
        fours = random.randint(0, 6)
        sixes = random.randint(0, 3)
        wickets = random.randint(0, 3)
        
        # Batting points
        points += runs * Batsman_points['Run']
        points += fours * Batsman_points['bFour']
        points += sixes * Batsman_points['bSix']
        
        if runs >= 50:
            points += Batsman_points['Half_century']
        elif runs >= 30:
            points += Batsman_points['30Runs']
        
        # Bowling points
        points += wickets * Bowling_points['Wicket']
        if wickets >= 3:
            points += Bowling_points['3W']
    
    elif position == 'Wicket-keeper':
        # Simulate wicket-keeper performance
        runs = random.randint(15, 75)
        fours = random.randint(0, 7)
        sixes = random.randint(0, 3)
        catches = random.randint(0, 4)
        stumpings = random.randint(0, 2)
        
        # Batting points
        points += runs * Batsman_points['Run']
        points += fours * Batsman_points['bFour']
        points += sixes * Batsman_points['bSix']
        
        if runs >= 50:
            points += Batsman_points['Half_century']
        elif runs >= 30:
            points += Batsman_points['30Runs']
        
        # Fielding points
        points += catches * Fielding_points['Catch']
        points += stumpings * Fielding_points['Stumping']
        
        if catches >= 3:
            points += Fielding_points['3Cath']
    
    return round(points, 1)

def generate_dream11_team(players_data, budget=100.0):
    """Generate optimal Dream11 team using algorithm"""
    # Convert to DataFrame for easier manipulation
    df = pd.DataFrame(players_data)
    
    # Calculate fantasy points for each player
    df['fantasy_points'] = df.apply(lambda row: calculate_fantasy_points(
        row['name'], row['position']
    ), axis=1)
    
    # Calculate value (fantasy points per cost)
    df['value'] = df['fantasy_points'] / df['price']
    
    # Define constraints (exactly 11 players)
    constraints = {
        'Wicket-keeper': 1,
        'Batsman': 4,
        'Bowler': 3,
        'All-rounder': 3
    }
    
    selected_players = []
    total_cost = 0
    
    # Select players based on constraints and value
    for position, count in constraints.items():
        position_players = df[df['position'] == position].sort_values('value', ascending=False)
        
        for i in range(count):
            if i < len(position_players):
                player = position_players.iloc[i]
                if total_cost + player['price'] <= budget:
                    selected_players.append({
                        'id': player['id'],
                        'name': player['name'],
                        'position': player['position'],
                        'price': player['price'],
                        'team_name': player['team_name'],
                        'image_url': player['image_url'],
                        'fantasy_points': player['fantasy_points']
                    })
                    total_cost += player['price']
    
    # If we don't have exactly 11 players, fill with best value players
    if len(selected_players) < 11:
        remaining_players = df[~df['id'].isin([p['id'] for p in selected_players])]
        needed = 11 - len(selected_players)
        
        for _, player in remaining_players.head(needed).iterrows():
            if total_cost + player['price'] <= budget:
                selected_players.append({
                    'id': player['id'],
                    'name': player['name'],
                    'position': player['position'],
                    'price': player['price'],
                    'team_name': player['team_name'],
                    'image_url': player['image_url'],
                    'fantasy_points': player['fantasy_points']
                })
                total_cost += player['price']
    
    # If we still don't have 11 players, relax budget constraint
    if len(selected_players) < 11:
        remaining_players = df[~df['id'].isin([p['id'] for p in selected_players])]
        needed = 11 - len(selected_players)
        
        for _, player in remaining_players.head(needed).iterrows():
            selected_players.append({
                'id': player['id'],
                'name': player['name'],
                'position': player['position'],
                'price': player['price'],
                'team_name': player['team_name'],
                'image_url': player['image_url'],
                'fantasy_points': player['fantasy_points']
            })
            total_cost += player['price']
    
    # Ensure we have exactly 11 players
    if len(selected_players) > 11:
        selected_players = selected_players[:11]
        total_cost = sum(p['price'] for p in selected_players)
    
    # Select captain and vice-captain (highest fantasy points)
    if selected_players:
        selected_players.sort(key=lambda x: x['fantasy_points'], reverse=True)
        captain = selected_players[0].copy()
        vice_captain = selected_players[1].copy() if len(selected_players) > 1 else selected_players[0].copy()
        
        # Double captain points
        captain['fantasy_points'] *= 2
        vice_captain['fantasy_points'] *= 1.5
        
        return selected_players, captain, vice_captain, total_cost
    
    return [], None, None, 0

@app.route('/')
def home():
    """Homepage - static landing page"""
    return render_template('home.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    """Login page"""
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        
        user = db.authenticate_user(email, password)
        if user:
            session['user_id'] = user['id']
            session['email'] = user['email']
            session['is_admin'] = user['is_admin']
            flash('Login successful!', 'success')
            return redirect(url_for('index'))
        else:
            flash('Invalid email or password!', 'error')
    
    return render_template('login.html')

@app.route('/signup', methods=['GET', 'POST'])
def signup():
    """Signup page"""
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        pan = request.form['pan']
        aadhaar = request.form['aadhaar']
        address = request.form['address']
        gender = request.form['gender']
        referral = request.form.get('referral', '')
        
        if db.create_user(email, password, pan, aadhaar, address, gender, referral):
            flash('Account created successfully! Please login.', 'success')
            return redirect(url_for('login'))
        else:
            flash('Email already exists!', 'error')
    
    return render_template('login.html', signup=True)

@app.route('/logout')
def logout():
    """Logout user"""
    session.clear()
    flash('Logged out successfully!', 'success')
    return redirect(url_for('home'))

@app.route('/index')
def index():
    """Match selection page"""
    if 'user_id' not in session:
        flash('Please login first!', 'error')
        return redirect(url_for('login'))
    
    matches = db.get_all_matches()
    return render_template('index.html', matches=matches)

@app.route('/player/<int:match_id>')
def player_selection(match_id):
    """Player selection page"""
    if 'user_id' not in session:
        flash('Please login first!', 'error')
        return redirect(url_for('login'))
    
    # Get match details
    matches = db.get_all_matches()
    match = next((m for m in matches if m['id'] == match_id), None)
    
    if not match:
        flash('Match not found!', 'error')
        return redirect(url_for('index'))
    
    # Load players from Excel files
    team1_players = load_team_players_from_excel(match['team1_name'])
    team2_players = load_team_players_from_excel(match['team2_name'])
    
    # Combine players from both teams
    players = team1_players + team2_players
    
    # Add unique IDs and ensure all required fields are present
    for i, player in enumerate(players):
        player['id'] = i + 1
        # Ensure all required fields are present
        if 'image_url' not in player:
            player['image_url'] = f"https://ui-avatars.com/api/?name={player['name'].replace(' ', '+')}&size=150&background=667eea&color=fff&bold=true"
        if 'position' not in player:
            player['position'] = 'Batsman'
        if 'price' not in player:
            player['price'] = 8.0
    
    return render_template('player.html', match=match, players=players, team1_id=1, team2_id=2)

@app.route('/generate_team', methods=['POST'])
def generate_team():
    """Generate Dream11 team using ML predictions"""
    if 'user_id' not in session:
        return jsonify({'error': 'Please login first!'}), 401
    
    data = request.get_json()
    print(f"Received data: {data}")  # Debug print
    
    match_id = data.get('match_id')
    selected_players = data.get('selected_players', [])
    team1_id = data.get('team1_id')
    team2_id = data.get('team2_id')
    use_ml = data.get('use_ml', True)  # Default to ML, allow fallback
    
    print(f"Selected players: {selected_players}, Count: {len(selected_players)}")  # Debug print
    
    if len(selected_players) < 22:  # Changed from 11 to 22 (11 from each team)
        return jsonify({'error': f'Please select exactly 11 players from each team (22 total)! Currently selected: {len(selected_players)}'}), 400
    
    try:
        # Get match details
        matches = db.get_all_matches()
        match = next((m for m in matches if m['id'] == match_id), None)
        if not match:
            return jsonify({'error': 'Match not found!'}), 404
        
        # Get team names
        team1_name = match['team1_name']
        team2_name = match['team2_name']
        
        # Load all players from Excel files
        all_team1_players = load_team_players_from_excel(team1_name)
        all_team2_players = load_team_players_from_excel(team2_name)
        all_players = all_team1_players + all_team2_players
        
        # Add unique IDs
        for i, player in enumerate(all_players):
            player['id'] = i + 1
        
        # Filter selected players - support either list of ints (ids) or list of player dicts
        if len(selected_players) > 0 and isinstance(selected_players[0], dict):
            # Client sent full player objects
            selected_players_data = selected_players
        else:
            selected_players_data = [p for p in all_players if p['id'] in selected_players]
        
        # Get player names for each team
        team1_players = [p['name'] for p in selected_players_data if p['team_name'] == team1_name]
        team2_players = [p['name'] for p in selected_players_data if p['team_name'] == team2_name]
        
        if use_ml:
            try:
                # Use ML-based team generation
                ml_predictor = get_ml_predictor()
                result_players, total_cost = ml_predictor.generate_ml_team(
                    [p for p in selected_players_data if p['team_name'] == team1_name],
                    [p for p in selected_players_data if p['team_name'] == team2_name],
                    budget=100.0
                )
                
                # Ensure we have exactly 11 players
                if len(result_players) < 11:
                    print("ML team generation didn't produce 11 players, falling back to manual")
                    raise Exception("Insufficient players from ML")
                
            except Exception as e:
                print(f"ML team generation failed: {e}, falling back to manual algorithm")
                use_ml = False
        
        if not use_ml:
            # Fallback to original algorithm
            # Calculate fantasy points for team 1
            team1_fp = get_team_fantasy_points(team1_players)
            team2_fp = get_team_fantasy_points(team2_players)
            
            # Get fantasy points for both teams
            t1 = get_players(team1_players, team2_players, team1_fp)
            t2 = get_players(team2_players, team1_players, team2_fp)
            
            # Combine and sort by points
            t3 = t1 + t2
            t3.sort(reverse=True)
            
            # Get top 11 players
            top_11 = t3[:11]
            
            # Create result with player details
            result_players = []
            for points, player_name in top_11:
                player_data = next((p for p in selected_players_data if p['name'] == player_name), None)
                if player_data:
                    # Ensure all required fields are present with defaults
                    result_players.append({
                        'id': player_data.get('id', 0),
                        'name': player_data.get('name', player_name),
                        'position': player_data.get('position', 'Batsman'),
                        'price': player_data.get('price', 8.0),
                        'team_name': player_data.get('team_name', 'Unknown'),
                        'image_url': player_data.get('image_url', f"https://ui-avatars.com/api/?name={player_name.replace(' ', '+')}&size=150&background=667eea&color=fff&bold=true"),
                        'fantasy_points': points
                    })
            
            total_cost = sum(p.get('price', 0) for p in result_players)
        
        # Select captain and vice-captain (highest fantasy points)
        captain = None
        vice_captain = None
        if result_players:
            # mark captain/vice flags inside result_players so we can persist them
            result_players.sort(key=lambda x: x['fantasy_points'], reverse=True)
            result_players[0]['is_captain'] = True
            if len(result_players) > 1:
                result_players[1]['is_vice_captain'] = True

            captain = result_players[0].copy()
            vice_captain = result_players[1].copy() if len(result_players) > 1 else result_players[0].copy()

        # Attempt to map captain/vice to DB ids (may be None if no mapping)
        captain_db_id = None
        vice_captain_db_id = None
        try:
            if captain:
                captain_db_id = db.get_player_id_by_name_and_team(captain['name'], captain['team_name'])
            if vice_captain:
                vice_captain_db_id = db.get_player_id_by_name_and_team(vice_captain['name'], vice_captain['team_name'])
        except Exception:
            captain_db_id = None
            vice_captain_db_id = None

        # Ensure every player dict has an image_url (provide placeholder if missing)
        placeholder = f"https://ui-avatars.com/api/?name=Player&size=150&background=667eea&color=fff&bold=true"
        for p in result_players:
            if not p.get('image_url'):
                p['image_url'] = placeholder

        # Save full player details JSON to database so result page can render even
        # if Excel IDs don't map to DB player IDs. Also pass mapped captain/vice DB ids when available.
        selection_id = db.save_match_selection(
            session['user_id'],
            match_id,
            json.dumps(result_players),
            captain_db_id,
            vice_captain_db_id,
            total_cost=total_cost,
            total_points=sum(p.get('fantasy_points', 0) for p in result_players)
        )
        
        return jsonify({
            'team': result_players,
            'captain': captain,
            'vice_captain': vice_captain,
            'total_cost': total_cost,
            'selection_id': int(selection_id) if selection_id else None,
            'method': 'ML' if use_ml else 'Manual'
        })
        
    except Exception as e:
        print(f"Error generating team: {e}")
        import traceback
        traceback.print_exc()
        return jsonify({'error': f'An error occurred while generating the team: {str(e)}'}), 500

@app.route('/result/<int:selection_id>')
def result(selection_id):
    """Show prediction results"""
    if 'user_id' not in session:
        flash('Please login first!', 'error')
        return redirect(url_for('login'))
    
    # Get selection details from database
    conn = db.get_connection()
    cursor = conn.cursor()
    
    cursor.execute("""
        SELECT ms.selected_players, ms.captain_id, ms.vice_captain_id,
               m.match_date, m.venue,
               t1.name as team1_name, t1.short_name as team1_short,
               t2.name as team2_name, t2.short_name as team2_short
        FROM match_selections ms
        JOIN matches m ON ms.match_id = m.id
        JOIN teams t1 ON m.team1_id = t1.id
        JOIN teams t2 ON m.team2_id = t2.id
        WHERE ms.id = ? AND ms.user_id = ?
    """, (selection_id, session['user_id']))
    
    selection = cursor.fetchone()
    conn.close()
    
    if not selection:
        flash('Selection not found!', 'error')
        return redirect(url_for('index'))
    
    # Get player details
    saved = json.loads(selection[0])

    # saved may be a list of dicts (result_players) or a list of DB ids
    if saved and isinstance(saved[0], dict):
        # Already full player dicts saved
        selected_players = saved
    else:
        # Treat as DB ids
        selected_players = db.get_players_by_ids(saved)

    # Determine captain/vice-captain
    captain = None
    vice_captain = None
    try:
        if saved and isinstance(saved[0], dict):
            # If full dicts were saved, they may include is_captain / is_vice_captain flags
            captain = next((p for p in selected_players if p.get('is_captain')), None)
            vice_captain = next((p for p in selected_players if p.get('is_vice_captain')), None)
            # Also try to populate DB ids if missing
            if captain and 'id' in captain and isinstance(captain['id'], int):
                # already an id
                pass
        else:
            # saved is list of DB ids
            try:
                captain = next((p for p in selected_players if p['id'] == selection[1]), None)
                vice_captain = next((p for p in selected_players if p['id'] == selection[2]), None)
            except Exception:
                captain = None
                vice_captain = None
    except Exception:
        captain = None
        vice_captain = None
    
    return render_template('result.html', 
                         players=selected_players,
                         captain=captain,
                         vice_captain=vice_captain,
                         match_date=selection[3],
                         venue=selection[4],
                         team1_name=selection[5],
                         team1_short=selection[6],
                         team2_name=selection[7],
                         team2_short=selection[8])

@app.route('/history')
def history():
    """User history page"""
    if 'user_id' not in session:
        flash('Please login first!', 'error')
        return redirect(url_for('login'))
    
    selections = db.get_user_history(session['user_id'])
    return render_template('history.html', selections=selections)

@app.route('/admin')
def admin():
    """Admin dashboard"""
    if 'user_id' not in session or not session.get('is_admin'):
        flash('Access denied! Admin privileges required.', 'error')
        return redirect(url_for('index'))
    
    users = db.get_all_users()
    teams = db.get_all_teams()
    return render_template('admin.html', users=users, teams=teams)

@app.route('/admin/toggle_user/<int:user_id>', methods=['POST'])
def toggle_user(user_id):
    """Toggle user active status"""
    if 'user_id' not in session or not session.get('is_admin'):
        return jsonify({'error': 'Access denied!'}), 403
    
    # Get current status
    user = db.get_user_by_id(user_id)
    if not user:
        return jsonify({'error': 'User not found!'}), 404
    
    new_status = not user['is_active']
    db.toggle_user_status(user_id, new_status)
    
    return jsonify({'success': True, 'is_active': new_status})

@app.route('/admin/toggle_team/<int:team_id>', methods=['POST'])
def toggle_team(team_id):
    """Toggle team active status"""
    if 'user_id' not in session or not session.get('is_admin'):
        return jsonify({'error': 'Access denied!'}), 403
    
    # Get current status
    teams = db.get_all_teams()
    team = next((t for t in teams if t['id'] == team_id), None)
    if not team:
        return jsonify({'error': 'Team not found!'}), 404
    
    new_status = not team.get('is_active', True)
    db.toggle_team_status(team_id, new_status)
    
    return jsonify({'success': True, 'is_active': new_status})

@app.route('/fantasy')
def fantasy_calculator():
    """Fantasy points calculator page"""
    if 'user_id' not in session:
        flash('Please login first!', 'error')
        return redirect(url_for('login'))
    
    # Get teams from Excel files
    teams = []
    for team_name in TEAM_MAPPING.keys():
        teams.append({
            'id': len(teams) + 1,
            'name': team_name,
            'short_name': TEAM_MAPPING[team_name].upper()
        })
    
    return render_template('fantasy.html', team_names=list(TEAM_MAPPING.keys()))

@app.route('/compare', methods=['GET', 'POST'])
def compare_teams():
    """Teams comparison page - head-to-head style summary using Excel rosters and historical points"""
    if 'user_id' not in session:
        flash('Please login first!', 'error')
        return redirect(url_for('login'))
    
    teams = list(TEAM_MAPPING.keys())
    if not teams:
        return render_template('compare.html', teams=[], team_a='', team_b='', team_a_points=[], team_b_points=[])
    
    team_a = request.values.get('team_a') or teams[0]
    team_b = request.values.get('team_b') or (teams[1] if len(teams) > 1 else teams[0])
    
    def build_points(players):
        results = []
        for p in players:
            fp = calculate_player_fantasy_points(p['name'])
            results.append({'name': p['name'], 'position': p['position'], 'points': fp})
        results.sort(key=lambda x: x['points'], reverse=True)
        return results
    
    players_a = load_team_players_from_excel(team_a)
    players_b = load_team_players_from_excel(team_b)
    team_a_points = build_points(players_a)
    team_b_points = build_points(players_b)
    
    return render_template('compare.html', teams=teams, team_a=team_a, team_b=team_b,
                           team_a_points=team_a_points, team_b_points=team_b_points)

@app.route('/about')
def about_page():
    return render_template('about.html')

@app.route('/contact')
def contact_page():
    return render_template('contact.html')




@app.route('/get_team_players/<int:team_id>')
def get_team_players(team_id):
    """Get players for a specific team"""
    if 'user_id' not in session:
        return jsonify({'error': 'Please login first!'}), 401
    
    # Get team name from team_id
    team_names = list(TEAM_MAPPING.keys())
    if team_id > len(team_names):
        return jsonify({'error': 'Team not found!'}), 404
    
    team_name = team_names[team_id - 1]
    
    # Load players from Excel file
    players = load_team_players_from_excel(team_name)
    
    # Add unique IDs
    for i, player in enumerate(players):
        player['id'] = i + 1
    
    return jsonify({'players': players})

@app.route('/calculate_fantasy_points', methods=['POST'])
def calculate_fantasy_points_route():
    """Calculate fantasy points for selected players using new logic"""
    if 'user_id' not in session:
        return jsonify({'error': 'Please login first!'}), 401
    
    data = request.get_json()
    selected_players = data.get('players', [])
    
    # Fantasy calculator expects exactly 11 players (the user's selected team)
    if len(selected_players) != 11:
        return jsonify({'error': 'Please select exactly 11 players!'}), 400
    
    try:
        # Group by team names (if two different teams are mixed, we still compare across them)
        team_names_order = []
        for p in selected_players:
            if p['team_name'] not in team_names_order:
                team_names_order.append(p['team_name'])
        if len(team_names_order) == 1:
            # Split evenly if only one team name detected
            mid = len(selected_players) // 2
            team1_names = [p['name'] for p in selected_players[:mid]]
            team2_names = [p['name'] for p in selected_players[mid:]]
        else:
            team1_names = [p['name'] for p in selected_players if p['team_name'] == team_names_order[0]]
            team2_names = [p['name'] for p in selected_players if p['team_name'] == team_names_order[1]]
        
        team1_fp = get_team_fantasy_points(team1_names)
        team2_fp = get_team_fantasy_points(team2_names)
        t1 = get_players(team1_names, team2_names, team1_fp)
        t2 = get_players(team2_names, team1_names, team2_fp)
        t3 = t1 + t2
        t3.sort(reverse=True)
        
        # Use the selected 11 only; compute base points from our model and then apply multipliers
        # Build a quick lookup for selected player meta
        sel_by_name = {p['name']: p for p in selected_players}
        
        team_points = []
        total_points = 0.0
        for points, player_name in t3:
            if player_name in sel_by_name:
                meta = sel_by_name[player_name]
                final_points = float(points)
                multiplier = 1.0
                if meta.get('is_captain'):
                    multiplier = 2.0
                elif meta.get('is_vice_captain'):
                    multiplier = 1.5
                final_points *= multiplier
                team_points.append({
                    'id': meta['id'],
                    'name': meta['name'],
                    'position': meta['position'],
                    'team_name': meta['team_name'],
                    'base_points': round(float(points), 1),
                    'multiplier': multiplier,
                    'final_points': round(final_points, 1),
                    'is_captain': meta.get('is_captain', False),
                    'is_vice_captain': meta.get('is_vice_captain', False)
                })
        
        # Keep order by final points, limit to 11
        team_points.sort(key=lambda x: x['final_points'], reverse=True)
        team_points = team_points[:11]
        total_points = sum(p['final_points'] for p in team_points)
        
        return jsonify({
            'team_points': team_points,
            'total_points': round(total_points, 1),
            'captain': next((p for p in team_points if p['is_captain']), None),
            'vice_captain': next((p for p in team_points if p['is_vice_captain']), None)
        })
    except Exception as e:
        return jsonify({'error': f'Error calculating fantasy points: {e}'}), 500

@app.route('/get_team_players_by_name/<team_name>')
def get_team_players_by_name(team_name):
    """Get players for a specific team by name"""
    if 'user_id' not in session:
        return jsonify({'error': 'Please login first!'}), 401
    
    try:
        players = load_team_players_from_excel(team_name)
        return jsonify({'players': players})
    except Exception as e:
        print(f"Error loading team players for {team_name}: {e}")
        return jsonify({'error': 'Failed to load team players'}), 500

if __name__ == '__main__':
    app.run(debug=True)
