import json
from database import DatabaseManager

db=DatabaseManager()
print('History entries sample:')
print(json.dumps(db.get_user_history(1)[:2], indent=2))
