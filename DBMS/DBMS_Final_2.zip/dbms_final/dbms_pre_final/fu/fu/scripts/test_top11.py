import os
import sys
import traceback

# Ensure project root is on sys.path
project_root = r"c:\Users\BOINI RAJESH\Downloads\fu\fu"
if project_root not in sys.path:
    sys.path.insert(0, project_root)

try:
    from dream import load_team_players_from_excel, get_team_fantasy_points, get_players

    team1_name = 'Mumbai Indians'
    team2_name = 'Royal Challengers Bangalore'

    team1 = load_team_players_from_excel(team1_name)
    team2 = load_team_players_from_excel(team2_name)

    if not team1:
        print(f"No players loaded for {team1_name}. Check Teams/{team1_name} Excel file.")
    if not team2:
        print(f"No players loaded for {team2_name}. Check Teams/{team2_name} Excel file.")

    selected1 = [p['name'] for p in team1[:11]]
    selected2 = [p['name'] for p in team2[:11]]

    print('Selected team1 count:', len(selected1))
    print('Selected team2 count:', len(selected2))

    team1_fp = get_team_fantasy_points(selected1)
    team2_fp = get_team_fantasy_points(selected2)

    print('Sample team1 fantasy points items:', list(team1_fp.items())[:5])

    t1 = get_players(selected1, selected2, team1_fp)
    t2 = get_players(selected2, selected1, team2_fp)

    combined = t1 + t2
    combined.sort(reverse=True)

    print('\nTop 11 combined:')
    for pts, name in combined[:11]:
        print(name, pts)

except Exception as e:
    print('Error during test:')
    traceback.print_exc()
