import os, sys, json
project_root = r"c:\Users\BOINI RAJESH\Downloads\fu\fu"
if project_root not in sys.path:
    sys.path.insert(0, project_root)

from dream import load_team_players_from_excel, get_team_fantasy_points, get_players
from database import DatabaseManager

db = DatabaseManager()

team1_name = 'Royal Challengers Bangalore'
team2_name = 'Kolkata Knight Riders'
team1 = load_team_players_from_excel(team1_name)
team2 = load_team_players_from_excel(team2_name)

all_players = team1 + team2
for i,p in enumerate(all_players): p['id'] = i+1

selected_players = [p for p in all_players][:22]
team1_names = [p['name'] for p in selected_players[:11]]
team2_names = [p['name'] for p in selected_players[11:22]]

team1_fp = get_team_fantasy_points(team1_names)
team2_fp = get_team_fantasy_points(team2_names)

t1 = get_players(team1_names, team2_names, team1_fp)
t2 = get_players(team2_names, team1_names, team2_fp)
combined = t1 + t2
combined.sort(reverse=True)

top11 = combined[:11]

result_players = []
for pts,name in top11:
    p = next((x for x in selected_players if x['name']==name), None)
    if p:
        result_players.append({'id':p['id'],'name':p['name'],'team_name':p['team_name'],'position':p.get('position'),'price':p.get('price')})

# Map to DB ids using DatabaseManager
db_ids = []
for rp in result_players:
    db_id = db.get_player_id_by_name_and_team(rp['name'], rp['team_name'])
    db_ids.append(db_id)

print('Result players count:', len(result_players))
print('Mapped DB ids:', db_ids)

selection_id = db.save_match_selection(1, 2, json.dumps([did for did in db_ids if did]), None, None)
print('Saved selection id:', selection_id)

history = db.get_user_history(1)
print('User history entries:', len(history))
print(history[0] if history else 'No history')
