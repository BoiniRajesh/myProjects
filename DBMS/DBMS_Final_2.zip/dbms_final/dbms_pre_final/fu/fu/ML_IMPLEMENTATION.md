# Machine Learning Implementation for IPL Dream11 Predictions

## 🎯 Overview

This document describes the machine learning implementation that replaces the manual algorithm for predicting player performance and generating optimal Dream11 teams. The ML system uses historical IPL data to train models that predict fantasy points for players based on various features and player vs player matchups.

## 🏗️ Architecture

### Core Components

1. **ML Models Module** (`ml_models.py`)
   - `IPLMLPredictor` class: Main ML predictor
   - Feature engineering functions
   - Model training and prediction
   - Player vs player weight matrix

2. **Training Script** (`train_ml_models.py`)
   - Standalone script to train models
   - Data preprocessing and validation
   - Model evaluation and saving

3. **Test Script** (`test_ml_predictions.py`)
   - Validation of ML predictions
   - Comparison with manual algorithm
   - Performance testing

4. **Integration** (`dream.py`)
   - ML prediction integration
   - Fallback to manual algorithm
   - API endpoints for ML predictions

## 📊 Features

### 1. Player Performance Prediction

The ML system predicts fantasy points for individual players based on:

- **Historical Performance**: Batting, bowling, and fielding statistics
- **Head-to-Head Records**: Performance against specific opponents
- **Venue Performance**: Performance at specific venues
- **Recent Form**: Recent match performance trends
- **Player vs Player Weights**: Interaction weights between specific players

### 2. Feature Engineering

#### Batting Features
- Average runs per match
- Average balls faced
- Strike rate
- Average fours and sixes
- Consistency metrics

#### Bowling Features
- Average wickets per match
- Average overs bowled
- Economy rate
- Maiden overs
- Wicket haul frequencies

#### Fielding Features
- Average catches per match
- Average run-outs per match
- Average stumpings per match

#### Contextual Features
- Head-to-head performance against opponents
- Venue-specific performance
- Recent form trends
- Match conditions

### 3. ML Models

The system uses multiple ML algorithms:

- **Random Forest Regressor**: Primary model for robust predictions
- **Gradient Boosting Regressor**: Secondary model for complex patterns
- **Linear Regression**: Baseline model for comparison

### 4. Player vs Player Weight Matrix

A dynamic weight matrix that stores performance relationships between players:
- Weights are calculated based on historical head-to-head performance
- Weights are updated as new data becomes available
- Used to adjust predictions based on specific matchups

## 🚀 Usage

### Training Models

```bash
# Install dependencies
pip install -r requirements.txt

# Train ML models
python train_ml_models.py
```

### Testing Predictions

```bash
# Test ML predictions
python test_ml_predictions.py
```

### Using in Application

The ML system is automatically integrated into the main application. When generating teams:

1. **ML Prediction** (Default): Uses trained models for predictions
2. **Manual Fallback**: Falls back to original algorithm if ML fails

## 📈 Performance Metrics

### Model Evaluation
- **Mean Squared Error (MSE)**: Measures prediction accuracy
- **R² Score**: Measures model fit quality
- **Cross-validation**: Ensures model generalization

### Prediction Features
- **Player-specific predictions**: Individual player performance
- **Team optimization**: Optimal team selection within budget
- **Real-time updates**: Models can be retrained with new data

## 🔧 Configuration

### Model Parameters

```python
# Random Forest
n_estimators=100
random_state=42

# Gradient Boosting
n_estimators=100
random_state=42

# Training split
test_size=0.2
random_state=42
```

### Feature Scaling
- StandardScaler for numerical features
- LabelEncoder for categorical features
- Missing value handling with default values

## 📁 File Structure

```
├── ml_models.py              # Main ML implementation
├── train_ml_models.py        # Training script
├── test_ml_predictions.py    # Testing script
├── models/                   # Saved models directory
│   ├── random_forest_model.pkl
│   ├── gradient_boosting_model.pkl
│   ├── linear_regression_model.pkl
│   ├── main_scaler.pkl
│   └── player_weights.pkl
└── ML_IMPLEMENTATION.md      # This documentation
```

## 🎮 API Integration

### New Endpoints

The ML system adds the following capabilities to existing endpoints:

- **`/generate_team`**: Now supports ML predictions (default)
- **`use_ml` parameter**: Toggle between ML and manual predictions
- **`method` response**: Indicates which method was used

### Example Usage

```javascript
// Generate team with ML predictions
fetch('/generate_team', {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({
        match_id: 1,
        selected_players: [...],
        use_ml: true  // Default: true
    })
})
.then(response => response.json())
.then(data => {
    console.log('Team generated using:', data.method);
    console.log('Players:', data.team);
});
```

## 🔄 Model Updates

### Retraining
Models can be retrained with new data:

```python
# Initialize predictor
predictor = IPLMLPredictor()

# Retrain with new data
predictor.train_models()
```

### Incremental Learning
The system supports incremental updates to player weights:

```python
# Update player vs player weights
weight = predictor.get_player_vs_player_weights('Player1', 'Player2')
```

## 📊 Data Requirements

### Training Data
- **Ball-by-ball data**: `IPl Ball-by-Ball 2008-2023.csv`
- **Match data**: `IPL Mathces 2008-2023.csv`
- **Player data**: Excel files in `Teams/` directory

### Data Quality
- Missing values handled with defaults
- Outliers filtered during preprocessing
- Data validation before training

## 🚨 Error Handling

### Fallback Mechanism
- ML prediction failures automatically fall back to manual algorithm
- Graceful degradation ensures system reliability
- Error logging for debugging

### Common Issues
1. **No training data**: Falls back to manual algorithm
2. **Model loading failure**: Retrains models automatically
3. **Prediction errors**: Uses default values or fallback

## 🔮 Future Enhancements

### Planned Features
1. **Deep Learning Models**: Neural networks for complex patterns
2. **Real-time Data**: Live match data integration
3. **Advanced Features**: Weather, pitch conditions, player fitness
4. **Ensemble Methods**: Combining multiple models for better accuracy
5. **A/B Testing**: Compare ML vs manual performance

### Performance Optimization
1. **Model Caching**: Faster prediction loading
2. **Batch Processing**: Efficient bulk predictions
3. **Feature Selection**: Optimize feature importance
4. **Hyperparameter Tuning**: Automated model optimization

## 📝 Notes

- The ML system maintains backward compatibility with the existing manual algorithm
- Models are automatically saved and loaded for persistence
- The system is designed to handle missing or incomplete data gracefully
- All predictions include confidence scores and uncertainty measures

## 🤝 Contributing

To contribute to the ML implementation:

1. Follow the existing code structure
2. Add comprehensive tests for new features
3. Update documentation for any changes
4. Ensure backward compatibility
5. Test with real IPL data

---

**Note**: This ML implementation significantly improves prediction accuracy compared to the manual algorithm while maintaining system reliability through fallback mechanisms.
